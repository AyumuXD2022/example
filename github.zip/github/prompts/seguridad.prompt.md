---
mode: ask
description: "PASO 1 — Análisis de seguridad y corrección (sigue las instrucciones base)"
---

# PASO 1 — Análisis de seguridad

Revisa el código (o el archivo/selección indicado) y encuentra vulnerabilidades, siguiendo
la SEVERIDAD y el FORMATO DE SALIDA de las instrucciones base del repo. Qué buscar:

## Si ACCEDE A BD
- Inyección SQL/LDAP/OS command, incl. de segundo orden (usar PreparedStatement/parámetros).
- Credenciales/PIN en texto plano o hash débil (MD5/SHA-1, o SHA-256 pelón para passwords
  -> debe ser PBKDF2/bcrypt/scrypt/Argon2 con sal).
- Datos sensibles sin cifrar en reposo cuando el requerimiento lo exige.

## Si CONSUME REST/HTTP
- TLS inseguro: validación de certificado/hostname deshabilitada (TrustManager vacío,
  HostnameVerifier que retorna true, trustAllCerts, SSLContext permisivo). Sin timeouts.
- SSRF: URL/endpoint construido con entrada sin validar (usar allowlist de hosts).
- Secretos en el cliente: endpoints, API keys, tokens, usuario/clave hardcodeados o en
  config/logs; token en la URL en vez de headers; password de keystore hardcodeada.
- Datos sensibles en logs; deserialización JSON insegura (default/polymorphic typing).
- Inyección al downstream (CRLF/header injection), redirecciones a hosts no confiables.

## Si es SOAP (CXF / JAX-WS / Spring-WS)
- XXE: el parser XML debe deshabilitar DTD y entidades externas (SUPPORT_DTD=false,
  external-general/parameter-entities=false). Es EL finding típico.
- DoS XML: "billion laughs"/entidades expansivas, payloads enormes sin límite.
- WS-Security / credenciales: UsernameToken o usuario/clave hardcodeados, sin TLS,
  sin timestamp/nonce, o logueados (LoggingFeature/interceptor que imprime el sobre).
- Endpoint inseguro: servicio sobre HTTP, o ENDPOINT_ADDRESS_PROPERTY desde entrada no
  validada (SSRF). Validación de schema deshabilitada.
- SOAP/XPath injection; WSDL/stubs con endpoints o secretos embebidos.

## Si es WEB/API (Spring MVC/WebFlux)
- Spring Security: permitAll indebido, CSRF deshabilitado sin justificación, actuator
  expuesto sin auth, authz a nivel método faltante, session fixation.
- JWT: firma no verificada, alg "none", exp/iss/aud no validados, secreto hardcodeado.
- Cookies sin HttpOnly/Secure/SameSite; CORS con Allow-Origin: * y credenciales;
  headers de seguridad faltantes (X-Frame-Options/CSP).
- Mass assignment; XSS reflejado/almacenado (CWE-79): salida con datos sin escapar.

## SIEMPRE (todos los módulos)
- Cripto débil: ECB, IV fijo, llaves/IV hardcodeados, DES/3DES/RC4, llave < 256 bits
  (preferir AES-256-GCM).
- Secretos hardcodeados (CWE-798); Insecure Randomness (CWE-330: usar SecureRandom).
- Log Forging (CWE-117): entrada en logs sin neutralizar \r\n.
- Information Exposure (CWE-209): no devolver ni loguear stack traces/mensajes internos.
- Privacy Violation (CWE-359): PII (RFC, CURP, cuenta, tarjeta) sin enmascarar.
- Trust Boundary Violation (CWE-501); Path Traversal/Zip Slip (CWE-22/73).
- Deserialización insegura (CWE-502); ReDoS (CWE-1333).
- Validación de entrada, manejo de excepciones que filtra info, recursos sin cerrar,
  control de acceso faltante.

Entrega los hallazgos en el formato de las instrucciones base. Después ejecuta `/limpieza`.
