---
mode: ask
description: "PASO 0 — Documenta qué hace el proyecto antes de auditarlo"
---

# PASO 0 — Entiende y documenta el proyecto

Lee TODO el código del proyecto (usa @workspace / #codebase) y explica, en español y
basándote en el código real:

1) Propósito: qué resuelve, en 1 párrafo.
2) Flujo principal: punto de entrada -> pasos en orden -> salida.
3) Componentes clave: clases/métodos importantes y su responsabilidad (1 línea c/u).
4) Integraciones: BD (tablas/SP), servicios que consume (REST/SOAP + endpoint/operación),
   colas, archivos.
5) Entradas y salidas, y configuración relevante (sin mostrar secretos).
6) Diagrama de flujo simple (mermaid o ASCII).
7) Tipo de módulo: BD/JDBC, cliente REST/HTTP, SOAP (CXF/JAX-WS/Spring-WS), Web/API, o varias.

No inventes: si algo no se puede determinar, dilo explícitamente.
Después de este paso, ejecuta `/seguridad`.
