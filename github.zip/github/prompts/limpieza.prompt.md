---
mode: ask
description: "PASO 2 — Limpieza y calidad SonarQube (sin romper funcionalidad)"
---

# PASO 2 — Limpieza y calidad (SonarQube)

Revisa el código (o el archivo indicado) y propón limpieza + correcciones de calidad que
hacen fallar el Quality Gate de SonarQube, SIN romper la funcionalidad. Entrega antes/después.

## Limpieza
- Elimina código muerto: clases, métodos, variables, parámetros e imports NO usados.
- Reemplaza imports con comodín (ej. `import java.util.*;`) por imports EXPLÍCITOS de
  únicamente lo que se usa (una línea por cada tipo importado).
- Elimina código comentado sin motivo.

## Bugs típicos de Sonar
- Posible NullPointerException (desreferenciar algo que puede ser null).
- Recursos sin cerrar (InputStream, Connection, Statement) -> try-with-resources.
- Comparar String/objetos con `==` en vez de `.equals()`.
- Resultados de métodos ignorados, condiciones siempre true/false, `equals`/`hashCode` inconsistentes.

## Code smells típicos de Sonar
- Complejidad cognitiva alta / métodos muy largos -> extraer métodos.
- Código DUPLICADO -> extraer a un método o constante común.
- `System.out.println` / `printStackTrace` -> usar el logger.
- Bloques `catch` vacíos o que solo imprimen -> manejar, loguear con contexto o relanzar.
- Números/cadenas "mágicos" -> constantes; nombres poco claros -> renombrar.
- Modificadores innecesarios, campos que deberían ser `final`, variables sin usar.

## Security Hotspots
- Sonar marca "hotspots" para REVISIÓN (no son vulnerabilidades confirmadas): uso de cripto,
  aleatoriedad, deserialización, regex, manejo de archivos, etc.
- Revísalos: si hay riesgo real, corrígelo; si es seguro, explica por qué (para marcarlo revisado).

## Cuidado
- Un import/método que "parece" sin uso puede usarse por reflexión, inyección (Spring) o
  serialización. Si hay duda, márcalo "A revisar" en vez de eliminarlo/cambiarlo.
- No cambies el comportamiento: refactors mínimos y seguros.
- Después de aplicar, verifica que COMPILE y pasen las pruebas.

Cuando termines, ejecuta `/test`: ahí se vuelve a leer el código ya limpio para generar las
pruebas de cobertura sobre el estado final.
