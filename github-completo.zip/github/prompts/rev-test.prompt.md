---
mode: ask
description: "PASO 6 — Excluir el SOAP generado en Sonar/JaCoCo, agregar deps de test y verificar"
---

# PASO 6 — Pruebas, cobertura y exclusiones

ENTORNO: si NO tienes ya la RUTA local de Gradle y del JDK (del PASO 2 / `/rev-contexto`), PÍDELAS antes de
correr las pruebas. Lee la versión de Gradle (`gradle-wrapper.properties`) y de Java (`build.gradle`),
dísela a la persona y pídele solo la carpeta. NO descargues nada; NO uses `JAVA_HOME`: corre con
`-Dorg.gradle.java.home="<ruta_jdk>"`.

## 1) Releer el código
- Si se pasó por `/rev-checkmarx` (PASO 4) y/o `/rev-snyk` (PASO 5): vuelve a LEER las clases tocadas para
  ver qué cambió y confirmar que siguen funcionando igual.
- Si NO hubo esos informes: LEE todo el código (por paquetes si es grande) para partir del estado real.

## 2) Exclusiones en sonar-project.properties (NO lo crees — YA existe)
- El proyecto YA tiene su `sonar-project.properties`. NUNCA lo crees ni lo reestructures.
- Solo ÁBRELO y mira `sonar.exclusions` y `sonar.coverage.exclusions`.
- Al momento de testear, AGREGA a esas dos propiedades la CLASE GENERADA por el SOAP (el código
  de wsimport/xjc/wsdl2java que detectaste en `/rev-contexto`) para EXCLUIRLA del análisis y de la
  cobertura. Respeta el MISMO formato de rutas que ya use el archivo; no borres lo que ya esté.
- CONFIGURACIÓN: PRIMERO intenta PROBAR lo que tenga algo de lógica (una `@Configuration` que arma un
  bean con lógica, un converter, un validator, etc.) — probar es mejor que excluir. SOLO si de verdad
  NO hay nada que testear (puro cableado, constantes, enums, `@SpringBootApplication` main), exclúyelo
  de la COBERTURA (`sonar.coverage.exclusions`, no de `sonar.exclusions`) para que no aparezca en 0%.
  La decisión FINAL de qué excluir se toma en el paso 6 MIRANDO el reporte (las clases en 0%).
  NO excluyas código de NEGOCIO (servicios, lógica, mappers con reglas): eso se prueba.

## 3) Dependencias de prueba (agrega SOLO las de test que falten)
- PRIMERO LEE el `build.gradle` para ver qué dependencias ya existen (no dupliques) y en qué scope.
- Si faltan dependencias para poder probar, AGRÉGALAS pero SOLO de ámbito de PRUEBA
  (`testImplementation` / `testRuntimeOnly` / `testCompileOnly` / `testAnnotationProcessor`).
  NUNCA agregues ni cambies dependencias de producción (`implementation`/`api`/`compileOnly`):
  este paso solo toca lo de TEST. Reporta cuáles agregaste y por qué.
- Usa los nombres de artefacto CORRECTOS. OJO con estos errores comunes:
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc'  -> MVC va en 'spring-boot-starter-web'
    * NO existe 'org.springframework.boot:spring-boot-starter-security-test'
         -> es 'org.springframework.security:spring-security-test'
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc-test'
         -> @WebMvcTest/MockMvc ya vienen en 'spring-boot-starter-test'
- Base de pruebas (casi siempre):
    testImplementation 'org.springframework.boot:spring-boot-starter-test'   // JUnit5 + Mockito + AssertJ + MockMvc
    testRuntimeOnly   'org.junit.platform:junit-platform-launcher'
- Según lo que use el módulo (agrega solo lo que aplique):
    Spring Security -> testImplementation 'org.springframework.security:spring-security-test'
    Lombok en tests -> testCompileOnly 'org.projectlombok:lombok'
                       testAnnotationProcessor 'org.projectlombok:lombok'
    WebFlux/Reactor -> testImplementation 'io.projectreactor:reactor-test'
    Cliente REST    -> testImplementation 'com.squareup.okhttp3:mockwebserver'  (o WireMock)
    JPA / BD        -> 'com.h2database:h2' o Testcontainers
- Deja la versión al BOM de Spring Boot cuando aplique (sin número). Si ya están, no las dupliques.

## 4) Generar las pruebas (meta: >= 85%, ideal 100%)
- JUnit 5 + Mockito. Slice correcto: `@ExtendWith(MockitoExtension.class)` (servicios),
  `@WebMvcTest` (controllers), `@DataJpaTest`/repos mockeados (datos). Patrón AAA, nombres claros.
- Mockea TODA dependencia externa (BD/Connection, clientes SOAP/REST, colas, config). Aserciones reales.
- Cubre lo NO excluido: métodos públicos (camino feliz + error), ramas (if/else, switch, catch, null).

## 5) Correr pruebas + JaCoCo y LEER los resultados
- Corre con el gradle y JDK locales (PASO 2):
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"
- Cuando TODAS pasen, LEE el reporte de JaCoCo (`build/reports/jacoco/test/html/index.html` o el
  `jacocoTestReport.xml`). Si no lo encuentras, PIDE la RUTA y léelo en ese momento (ej.
  `/pega-baas-debit-card-transactions/build/reports/jacoco/test/html/index.html`).

## 6) Mirar las clases en 0%, clasificarlas y excluir solo lo que corresponde (y re-verificar)
- En el reporte, LOCALIZA las clases que quedaron en 0% (o muy bajas). Para CADA una, decide:
  * ¿Es código GENERADO por el SOAP? -> exclúyela.
  * ¿Es pura CONFIGURACIÓN / sin lógica que probar (config, `@SpringBootApplication` main, constantes,
    enums, pojo/dto sin lógica)? -> exclúyela.
  * ¿Tiene lógica de NEGOCIO? -> NO la excluyas: AGRÉGALE pruebas para subir su cobertura.
- Lo que toque excluir, agrégalo al `exclude` del bloque `jacocoTestReport` del `build.gradle` (MISMO
  formato de ruta; deriva el paquete real del `build.gradle`/`contexto`, no copies ejemplos de otro repo)
  y a `sonar.coverage.exclusions`. Así esas clases ya NO salen en 0% ni bajan el %.
- Plantilla de referencia (ajusta los paquetes a ESTE proyecto):

    jacocoTestReport {
        dependsOn test
        reports {
            xml.required.set(true)
            csv.required.set(true)
            html.required.set(true)
        }
        afterEvaluate {
            classDirectories.setFrom(files(classDirectories.files.collect {
                fileTree(dir: it, exclude: [
                    // paquete GENERADO del SOAP/XSD de ESTE proyecto, ej.:
                    'com/bns/xsd/**',
                    'com/<paquete>/<generado>/**',
                    // clases SOLO de configuración / sin lógica que probar (ajusta a ESTE proyecto):
                    'com/<paquete>/config/**',
                    'com/<paquete>/constants/**',
                    'com/<paquete>/**/*Application.*'
                ])
            }))
        }
    }
    jacocoTestCoverageVerification {
        violationRules { rule { limit { minimum = 0.1 } } }
    }

- VUELVE a correr `test jacocoTestReport` y VERIFICA en el reporte que las clases que excluiste (SOAP y
  configuración) ya NO aparecen y que la cobertura refleja el cambio. Si alguna sigue apareciendo,
  revisa la ruta del `exclude` y repite hasta que quede bien excluida.
- NO excluyas tu código de negocio para "inflar" cobertura. Si una clase propia queda baja, AGREGA
  pruebas, no la excluyas.

## Entrega
- Qué se agregó a `sonar.exclusions` / `sonar.coverage.exclusions` y al `exclude` de `jacocoTestReport`.
- Dependencias de test agregadas (solo test) y por qué.
- Pruebas generadas (código completo) y cobertura final; qué falta para el 85% si no se llegó.
- Jamás `git push`/commit/PR.
