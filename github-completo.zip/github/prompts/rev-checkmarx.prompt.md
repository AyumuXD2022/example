---
mode: ask
description: "PASO 4 — Mitigar hallazgos de Checkmarx (solo si hay informe)"
---

# PASO 4 — Checkmarx (mitigar hallazgos)

ENTORNO (si lo vas a compilar/verificar): si NO tienes ya la RUTA local de Gradle y del JDK (del
PASO 2 / `/rev-contexto`), PÍDELAS antes de compilar. Lee la versión de Gradle (`gradle-wrapper.properties`)
y de Java (`build.gradle`), dísela a la persona y pídele solo la carpeta. NO descargues nada; NO uses
`JAVA_HOME`: corre con `-Dorg.gradle.java.home="<ruta_jdk>"`.

PRIMERO PREGUNTA: "¿Tienes un informe de Checkmarx?"

- Si la persona dice **NO**: no hagas nada aquí, pasa directo a `/rev-snyk`.
- Si dice **SÍ**: pídele que te PASE el informe (o el hallazgo) y que te diga **EN QUÉ CLASE/archivo**
  está cada hallazgo. No adivines; trabaja solo sobre lo que te pase.

## Antes de corregir
- LEE el `build.gradle` (regla base). NO agregues código que dependa de una librería que el proyecto
  NO tiene. Si una corrección necesitara una dependencia nueva, DILO y deja que la persona decida;
  prioriza arreglarlo con lo que ya está en el proyecto.

## Cómo mitigar cada hallazgo
1) Ubica la clase/línea exacta del informe.
2) Explica brevemente qué es el hallazgo (query de Checkmarx / CWE si viene en el informe) y por qué
   aplica aquí.
3) Da el código VULNERABLE (antes) y el CORREGIDO (después): mínimo, idiomático y con librerías ya
   presentes. Explica por qué cierra el flujo que marca Checkmarx (fuente -> sink).
4) Si crees que es FALSO POSITIVO, dilo y justifícalo (para marcarlo "Not Exploitable").
5) NO rompas la funcionalidad. Si un arreglo necesita decisión de negocio, plantéala y recomienda.

## Entrega
- Lista de hallazgos del informe con su estado: corregido / falso positivo / A revisar.
- El antes/después de cada clase tocada.
- Jamás `git push`/commit/PR.

Al terminar, depende del tipo de proyecto (visto en `/rev-contexto`):
- Si es Spring: ejecuta `/rev-snyk`.
- Si es Java normal (sin Spring): aquí TERMINA el flujo. No ejecutes `/rev-snyk` ni `/rev-test`.
  (Y si en este proyecto Java normal no había informe de Checkmarx, el flujo ya terminó en `/rev-limpieza`.)
