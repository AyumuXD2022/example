# INSTRUCCIONES COMPLETAS — Migración a Arquitectura Hexagonal (todo en uno)

Pega este archivo COMPLETO en Copilot Chat con #file: y pídele que lo aplique.
Flujo de 5 pasos: contexto -> limpieza -> hexagonal (+diagrama) -> documentar -> test.
NUNCA hace git commit/push/PR en NINGÚN paso.

============================================================
## BASE (aplica siempre) + Entorno
============================================================

## Rol
Actúa como ARQUITECTO/DESARROLLADOR SENIOR Java / Spring Boot. Respondes en español, te basas en el
código REAL. No inventes. Tu objetivo es reorganizar el proyecto a HEXAGONAL conservando EXACTAMENTE
la misma funcionalidad de negocio.

## Reglas globales (OBLIGATORIAS en todos los pasos)
- ANTES de agregar CUALQUIER código o dependencia, LEE el `build.gradle` (y el BOM). Usa SOLO
  librerías/APIs que el proyecto YA tiene. NO pongas código de una dependencia que NO existe. Si de
  verdad hace falta una nueva, DILO y deja que la persona decida (excepción: dependencias de TEST en
  el paso 5).
- NO cambies la FUNCIONALIDAD DE NEGOCIO: el comportamiento observable debe quedar idéntico. Mover y
  reorganizar sí; cambiar lo que hace el código, no. Todo con ANTES/DESPUÉS.
- NUNCA descargues Gradle ni el JDK (ver "## Entorno"). Usa el Gradle y el JDK locales.
- NUNCA ejecutes `git add`, `git commit`, `git push` ni abras Pull Request, en NINGÚN paso. El commit
  lo hace la persona.
- Lo dudoso márcalo "A revisar" y explícalo; no lo cambies a ciegas.

## Entorno (nunca descargar Gradle ni el JDK)
- GRADLE: lee la versión en `gradle/wrapper/gradle-wrapper.properties` (campo `distributionUrl`) y
  DÍSELA a la persona (ej. "usa Gradle 8.14.3"). Luego pídele SOLO la RUTA/carpeta de ESA versión
  (ej. `C:\gradle\gradle-8.14.3`). TÚ completas el ejecutable (`\bin\gradle.bat` / `/bin/gradle`) y el
  comando con `--offline`. No uses `./gradlew` (baja la distribución).
- JDK: lee la versión de Java del `build.gradle` (`java { toolchain { languageVersion } }` o
  `sourceCompatibility`) y DÍSELA (ej. "usa Java 21"). Pídele SOLO la RUTA del JDK. NO uses `JAVA_HOME`:
  corre con `-Dorg.gradle.java.home="<ruta_del_jdk>"`. TÚ armas el comando.
- Comando de referencia:
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"

============================================================
## /contexto
============================================================


# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y entiende cómo funciona. NO cambies nada aquí.
Trabaja con el código REAL, no inventes. Si el repo es grande, ve por paquetes y DI cuáles revisaste.

## COBERTURA DE LECTURA (dilo explícito)
- ENUMERA los paquetes/módulos de nivel alto y marca cuáles REVISASTE y cuáles NO alcanzaste a leer.
  Entrega: "Leídos: [...] / NO leídos (incompletos): [...]".
- Si hay paquetes NO leídos, AVISA que el mapa de flujo puede estar INCOMPLETO en esas zonas y
  recomienda revisarlos por módulo antes de que `/limpieza` borre algo que dependa de ellos. Esas zonas
  van "A revisar", nunca "no".

## ANTES DE TERMINAR — pregunta obligatoria si quedó algo sin leer
- Si hay CLASES sin leer o leídas a MEDIAS, NO cierres el contexto: LÍSTALAS por nombre (clase + archivo)
  marcando "sin leer" / "incompleta".
- PREGUNTA a la persona: "¿Quieres que lea COMPLETAS estas clases (me enfoco en ellas e ignoro el resto),
  o sigo con lo ya leído aunque queden incompletas?"
- Si SÍ: pídeselas con `#file:` (o ábrelas), LÉELAS COMPLETAS e ignora lo demás; completa el mapa.
- Si NO (o no responde): déjalas "A revisar / incompleta" y dilo, para que `/limpieza` no borre nada que
  dependa de ellas.

## Entorno (no descargues nada)
- Lee la versión de Gradle (`gradle-wrapper.properties`) y la de Java (`build.gradle`) y DÍSELAS a la
  persona (ej. "usa Gradle 8.14.3 y Java 21"). Pídele SOLO las RUTAS locales de esas versiones.
- Con esas rutas, indaga qué necesita el proyecto para compilar/correr en local (JDK correcto,
  `--offline`, etc.). TÚ armas los comandos; no uses `JAVA_HOME` ni `./gradlew`.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> proceso -> salida.
2. **Arquitectura ACTUAL**: cómo está organizado hoy (capas, paquetes). Identifica el estilo
   (MVC por capas, service/repository, "todo junto", etc.) y dibuja el mapa de paquetes.
3. **¿Base de datos?** motor y cómo accede (JPA/Hibernate, JdbcTemplate, Connection), entidades y
   queries principales.
4. **¿SOAP?** endpoint/WSDL y CON QUÉ HERRAMIENTA se generaron las clases (wsimport, CXF wsdl2java,
   Axis, xjc) y en qué PAQUETE quedan.
5. **¿REST o WebFlux?** si expone/consume REST (Spring MVC) o usa WebFlux/Reactor; con qué clientes
   (RestTemplate, WebClient, Feign).
6. **Generadores de clases**: LISTA TODAS las herramientas que generen clases (wsimport, xjc,
   wsdl2java, Axis), con su task del `build.gradle` y su paquete de salida. Ponlas TODAS.
7. **Config relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.
8. **CONFIGURACIÓN DE SEGURIDAD:** ¿hay? (Spring Security, filtros, JWT, WS-Security). Di qué clases la
   forman -> FORMAN PARTE DEL FLUJO, NO son muertas. Márcalas "en el flujo".
9. **CONFIGURACIÓN DE SOAP y CÓDIGO GENERADO:** ¿hay config de SOAP? (endpoint/cliente, CXF/JAX-WS, WSDL)
   -> parte del flujo. Identifica el PAQUETE de las clases GENERADAS por SOAP (wsimport/xjc/wsdl2java):
   NO todas se usan y eso es NORMAL; ese código NO se elimina. Marca el paquete "GENERADO — NO ELIMINAR".
10. **LÓGICA DE NEGOCIO Y FLUJO (importante para la limpieza):**
   - Traza el/los FLUJO(S) principal(es): del punto de entrada (controller/endpoint/listener/`main`) a
     la salida (BD, otro servicio, respuesta), pasando por services/clientes/utilidades.
   - Di dónde está la LÓGICA DE NEGOCIO real (reglas, cálculos, validaciones) y en qué clases/métodos.
   - CLASIFICA cada clase: ¿está EN el flujo o NO? (ojo: puede estar viva por Spring/reflexión/JPA/endpoints;
     y la config de seguridad/SOAP y TODO el generado por SOAP cuentan como "en el flujo / no eliminar").

## Entrega
- Resumen en español + tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`.
- Un mapa de la ARQUITECTURA ACTUAL (lista de paquetes/capas y qué hay en cada uno). Guarda esto:
  será la base del paso `/hexagonal` y del `/documentar`.
- Un MAPA DE FLUJO / clases: `| Clase | ¿En el flujo? (sí/no/A revisar) | Rol en el negocio | Quién la usa |`.
  Es la BASE de `/limpieza`. Lo que no puedas confirmar que NO se usa -> "A revisar", no "no".
- Un DIAGRAMA DEL FLUJO en **Mermaid** (`flowchart`): del punto de entrada a la salida con las clases
  reales por las que pasa (controller -> service -> repositorio/cliente -> BD/SOAP/REST). Nombres reales,
  no inventes. (Es el flujo ACTUAL; el diagrama hexagonal se hace luego en `/hexagonal`.)
- Marca "A revisar" lo que no pudiste confirmar.

RECUERDA (base): jamás `git push`/commit/PR; no agregues código de dependencias que no estén en el
`build.gradle`; no cambies funcionalidad de negocio.

Cuando termines, ejecuta `/limpieza`.

============================================================
## /limpieza
============================================================


# PASO 2 — Limpieza de código

ANTES DE EMPEZAR: LEE el `build.gradle` (y el BOM) para saber qué dependencias tiene el proyecto y
qué VERSIÓN DE JAVA usa (`java { toolchain { languageVersion } }` o `sourceCompatibility`). NO uses
APIs/clases de una librería que el proyecto NO tiene; básate SOLO en lo presente. Y APÉGATE a esa
versión de Java: no introduzcas sintaxis/APIs de una versión más nueva (JDK 8: nada de `var`,
`records`, switch expression, `List.of`, text blocks; JDK 11: nada posterior). Debe seguir compilando
con esa versión; si no la sabes, pregúntala.

## Antes de empezar (si lanzan este paso solo)
- ENTORNO: si vas a compilar/correr y NO tienes ya la RUTA local de Gradle y del JDK (del `/contexto`),
  PÍDELAS. NO descargues nada; NO uses `JAVA_HOME`: corre con `-Dorg.gradle.java.home="<ruta_jdk>"`.
- MAPA DEL CONTEXTO: si NO tienes el mapa de flujo/lógica de `/contexto`, AVÍSALO y recomienda correrlo
  primero (o arma un mapa mínimo del paquete a limpiar). No borres a ciegas sin saber qué está en el flujo.

## Orden de trabajo (hazlo en este orden), SIEMPRE con la MISMA funcionalidad y con ANTES/DESPUÉS
0) APÓYATE EN EL MAPA DE FLUJO / LÓGICA DE NEGOCIO de `/contexto` (qué clases están EN el flujo y cuáles
   NO, y dónde está la lógica real). Ese mapa decide qué se puede quitar. Ya tienes del inicio las
   dependencias y la versión de Java a la que apegarte.
1) MÉTODOS MUERTOS primero: mirando el flujo/lógica de negocio, elimina los MÉTODOS que no participan en
   el negocio y que nadie del flujo llama; igual variables/parámetros/imports sin usar, `import *` ->
   explícitos, y código comentado. (Cascada: ver abajo.) No toques el código generado (SOAP).
2) SIMPLIFICA el código que SÍ se usa (el del flujo/negocio): más simple y legible pero con EXACTAMENTE
   la misma funcionalidad (booleanos redundantes, `else` tras `return`, `if` con `&&`, operador diamante,
   casts redundantes, `try-with-resources`, duplicados a método privado). ANTES de simplificar un método
   ENTIENDE qué hace; si NO se puede sin arriesgar el comportamiento, déjalo igual (no pasa nada).
3) AL FINAL, ELIMINA LAS CLASES que NO están en el flujo ni en la lógica de negocio (las que el mapa de
   `/contexto` marcó "no"). Aplica la cascada. Para DTO/Entity (y model/vo/pojo):
   - clase DTO/Entity que NO está en el flujo -> elimínala.
   - clase DTO/Entity que SÍ está en el flujo -> DÉJALA TAL CUAL, NO le quites atributos aunque parezcan
     sin usar (un campo suele mapear BD/JSON o usarse por reflexión).
   - clase marcada "A revisar" en el mapa -> NO la borres.
   - NUNCA elimines el código GENERADO por SOAP (wsimport/xjc/wsdl2java) aunque algunas clases no se usen
     (es normal), ni las clases de CONFIGURACIÓN de SEGURIDAD o de SOAP (están "en el flujo").

## Imports explícitos (no nombres cualificados en el cuerpo)
- Si un tipo está escrito con su paquete completo, p. ej. `private com.mx.entity.Clase clase;`,
  cámbialo por un IMPORT explícito arriba + nombre SIMPLE: `import com.mx.entity.Clase;` y `private Clase clase;`.
- CHOQUE DE NOMBRES: si en el MISMO archivo se usan DOS clases distintas con el mismo nombre simple,
  no se pueden importar las dos. Entonces RENOMBRA una de las clases a un nombre claro y distinto, pon
  los imports explícitos de ambas, actualiza TODOS los usos y DOCUMENTA el antes -> después (archivo de
  la clase y dónde se usaba). Luego VERIFICA que compile. NO renombres el código GENERADO (SOAP) ni API
  pública consumida fuera del proyecto; en ese caso renombra la OTRA, y si ninguna se puede sin riesgo,
  déjalo con el paquete completo y dilo.
- Es cosmético/legibilidad: NO cambia la funcionalidad.

## Detectar CLASES HUÉRFANAS de verdad (re-lee módulo por módulo)
- ANTES de eliminar una clase, RE-LEE el proyecto MÓDULO POR MÓDULO mirando SOLO: los `.java`, los
  **properties/yml de Spring** y los **`.xml`** (config/beans, web.xml, mappers). IGNORA lo demás.
- Busca la clase en los TRES: `.java` (imports/tipos/new/anotaciones), properties/yml (su nombre
  completo como texto) y `.xml` (`class="..."`, `<bean class=...>`, handlers/filtros/listeners).
- Es HUÉRFANA solo si NO aparece en NINGUNO y el `/contexto` no la marcó "en el flujo". Si está en un
  properties o XML, NO es huérfana aunque el código Java no la use: déjala.

## Código muerto EN CASCADA
- Una referencia que viene de código MUERTO no cuenta como "uso". Si `A` usa a `B` pero `A` NO se usa
  en ningún lado, entonces `B` queda sin uso real: elimina las DOS.
- Hazlo en CASCADA: tras borrar una clase/método muerto, revisa lo que usaba; si quedó sin uso real,
  bórralo también. Repite hasta que no quede nada que solo dependiera de lo ya eliminado.
- NO aplica a DTO/Entity que SÍ se usan (no se tocan sus atributos).

## Seguro
- Para afirmar que algo no se usa, búscalo (`usages`/`search`); si no puedes verlo, NO lo borres.
- Cuidado con Spring/reflexión/JPA/serialización/endpoints. Ante CUALQUIER duda, "A revisar".
- No renombres API pública ni cambies firmas. Nada que cambie resultado o comportamiento observable.

## Cómo trabajar (OBLIGATORIO — para que sea lo más confiable posible)
1) POR PAQUETE/MÓDULO, no todo el repo de un jalón. Limpia UN paquete completo (métodos -> simplificar
   -> clases), compila y corre pruebas, y SOLO cuando pase sigue con el siguiente. Así ve bien los usos.
2) ANTES de eliminar CLASES, NO borres nada: entrega una TABLA con las clases candidatas y PIDE confirmación:
   `| Clase | Ubicación (archivo/paquete) | ¿En el flujo de negocio? (sí/no) | Motivo de eliminación |`
   - Para las candidatas pon "no" y el motivo (no es seguridad/SOAP/config y nadie del flujo la usa). Lo
     que no estés seguro va "A revisar", NO como candidato.
   - La persona confirma qué filas eliminar; solo borra las aprobadas. Si no responde, no borras nada.
3) NINGÚN cambio se da por bueno sin COMPILAR y que PASEN LAS PRUEBAS. Tras cada paquete corre
   `"<ruta_gradle>\bin\gradle.bat" clean test --offline -Dorg.gradle.java.home="<ruta_jdk>"`.
   Si algo se rompe por tu cambio -> REVIÉRTELO y repórtalo; no sigas mientras algo esté roto.

## Documentar (obligatorio en este paso)
- Entrega una lista de TODOS los cambios hechos: archivo, qué se eliminó o simplificó y por qué,
  con ANTES/DESPUÉS, y qué quedó "A revisar". Esto queda como registro del paso.
- Confirma que COMPILA y que TODAS las pruebas pasan (gradle/JDK locales).

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hexagonal`.

============================================================
## /hexagonal
============================================================


# PASO 3 — Migrar a Arquitectura Hexagonal (Ports & Adapters)

Toma la ARQUITECTURA ACTUAL documentada en `/contexto` y reorganiza el proyecto a HEXAGONAL,
conservando EXACTAMENTE la misma funcionalidad de negocio (mismo comportamiento observable). Esto es
REESTRUCTURAR (mover código y crear puertos/adaptadores), NO reescribir la lógica.

## Capas y qué va en cada una
- **domain** (núcleo): entidades/modelos de negocio, value objects, reglas y servicios de dominio.
  NO depende de Spring, ni de JPA, ni de SOAP/REST. Aquí viven también los **puertos** (interfaces):
    - puertos de ENTRADA (casos de uso): qué puede pedirse al negocio.
    - puertos de SALIDA (repositorios/clientes): qué necesita el negocio del exterior.
- **application** (casos de uso): orquesta el dominio implementando los puertos de entrada. Sin
  detalles de framework; depende solo de `domain`.
- **infrastructure / adapters** (lo de afuera):
    - adaptadores de ENTRADA: controllers REST (Spring MVC) o handlers WebFlux, listeners, endpoints SOAP.
    - adaptadores de SALIDA: implementaciones JPA/JdbcTemplate de los repositorios, clientes REST/SOAP
      (RestTemplate/WebClient/puertos JAX-WS), colas.
    - configuración de Spring (`@Configuration`, beans), mapeos DTO<->dominio.
- El código GENERADO por el SOAP (wsimport/xjc) se queda como está y se usa SOLO desde el adaptador
  de salida SOAP; no lo metas al dominio.

## Reglas de dependencia (clave del hexagonal)
- Las dependencias apuntan HACIA ADENTRO: infrastructure -> application -> domain. El dominio NO
  conoce a nadie de afuera.
- La comunicación con el exterior pasa SIEMPRE por un PUERTO (interfaz) y su ADAPTADOR.
- Mantén la misma funcionalidad: cada caso de uso debe producir el mismo resultado que hoy.

## Cómo hacerlo (seguro, por pasos)
1) Propón la nueva estructura de paquetes (domain/application/infrastructure) y MUÉSTRALA antes de mover.
2) Extrae interfaces (puertos) para lo que hoy son services/repositories; haz que las clases actuales
   pasen a ser adaptadores que las implementan.
3) Mueve el código a su capa, ajustando imports/paquetes. Usa SOLO dependencias ya presentes en el
   `build.gradle` (no agregues librerías nuevas sin avisar).
4) Conserva las firmas públicas y el comportamiento; si algo obliga a decidir, márcalo "A revisar".
5) Verifica que COMPILE y que las pruebas existentes sigan pasando (gradle/JDK locales).

## Diagrama al finalizar (obligatorio)
Entrega un diagrama de cómo quedó, en **Mermaid**, mostrando capas, puertos y adaptadores, y las
CLASES reales que ubicaste en cada una (las que leíste) con su funcionalidad. Ejemplo de forma:

```mermaid
flowchart TB
  subgraph Infra_In[Adaptadores de entrada]
    REST[XxxController (REST)]
    SOAPIN[XxxEndpoint (SOAP)]
  end
  subgraph App[Application - Casos de uso]
    UC[XxxUseCase impl]
  end
  subgraph Domain[Domain - Núcleo]
    MODEL[Xxx (modelo)]
    PIN[[Puerto entrada: XxxService]]
    POUT[[Puerto salida: XxxRepository]]
  end
  subgraph Infra_Out[Adaptadores de salida]
    JPA[XxxRepositoryJpa]
    SOAPCLI[XxxSoapClient]
  end
  REST --> PIN
  SOAPIN --> PIN
  PIN --> UC --> MODEL
  UC --> POUT
  POUT --> JPA
  POUT --> SOAPCLI
```

Acompaña el diagrama con una tabla `| Clase | Capa | Rol (puerto/adaptador/modelo/caso de uso) | Qué hace |`.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/documentar`.

============================================================
## /documentar
============================================================


# PASO 4 — Documentar el cambio de arquitectura

Genera la documentación que compara la arquitectura ANTES (la de `/contexto`) con la nueva
arquitectura HEXAGONAL (la de `/hexagonal`). No cambies código aquí; solo documentas.

## Qué entregar
1. **Resumen del cambio**: en 1-2 párrafos, qué se reorganizó y por qué (el negocio quedó igual).
2. **Antes vs Después (estructura)**: tabla o dos árboles de paquetes:
   - Árbol de paquetes ANTES.
   - Árbol de paquetes DESPUÉS (domain / application / infrastructure).
3. **Mapa de movimientos por clase**: tabla
   `| Clase | Ubicación ANTES | Ubicación DESPUÉS | Capa | Rol (puerto/adaptador/modelo/caso de uso) |`.
4. **Puertos y adaptadores creados**: lista de interfaces (puertos de entrada/salida) nuevas y qué
   clase las implementa (adaptador).
5. **Qué NO cambió**: deja claro que la funcionalidad de negocio es la misma (mismos resultados,
   mismos endpoints/contratos). Si algo quedó "A revisar", lístalo.
6. **Diagramas**: incluye el diagrama Mermaid del hexagonal (del paso 3) y, si ayuda, un diagrama
   simple del "antes" para comparar.

Formato: Markdown claro (sirve para un README o una wiki). No inventes; básate en lo que realmente
moviste y leíste.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/test`.

============================================================
## /test
============================================================


# PASO 5 — Pruebas, cobertura y exclusiones

ENTORNO: si NO tienes ya la RUTA local de Gradle y del JDK (del `/contexto`), PÍDELAS antes de correr las
pruebas. Lee la versión de Gradle (`gradle-wrapper.properties`) y de Java (`build.gradle`), dísela a la
persona y pídele solo la carpeta. NO descargues nada; NO uses `JAVA_HOME`: corre con
`-Dorg.gradle.java.home="<ruta_jdk>"`.

## 1) Dependencias de prueba (lee el build.gradle primero)
- PRIMERO LEE el `build.gradle` para ver qué dependencias ya existen (no dupliques) y en qué scope.
- Si faltan dependencias para poder probar, AGRÉGALAS pero SOLO de ámbito de PRUEBA
  (`testImplementation` / `testRuntimeOnly` / `testCompileOnly` / `testAnnotationProcessor`). NUNCA
  toques producción. Usa SOLO APIs de dependencias que estén en el `build.gradle`; no pongas código de
  una librería que no existe. Reporta qué agregaste y por qué.
- Nombres correctos (OJO con los que NO existen):
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc'  -> MVC va en 'spring-boot-starter-web'
    * NO existe 'org.springframework.boot:spring-boot-starter-security-test'
         -> es 'org.springframework.security:spring-security-test'
    * @WebMvcTest/MockMvc ya vienen en 'org.springframework.boot:spring-boot-starter-test'
- Base: `testImplementation 'org.springframework.boot:spring-boot-starter-test'` +
  `testRuntimeOnly 'org.junit.platform:junit-platform-launcher'`.

## 2) Exclusiones en sonar-project.properties (NO lo crees — YA existe)
- El proyecto YA tiene su `sonar-project.properties`. NUNCA lo crees ni lo reestructures.
- Solo ÁBRELO y mira `sonar.exclusions` y `sonar.coverage.exclusions`. AGREGA ahí la(s) clase(s)
  GENERADA(S) por el SOAP (wsimport/xjc/wsdl2java detectado en `/contexto`) para EXCLUIRLAS, con el
  MISMO formato de rutas que ya use el archivo, sin borrar lo demás. No excluyas tu código de negocio.
- CONFIGURACIÓN: PRIMERO intenta PROBAR lo que tenga lógica (una `@Configuration` que arma un bean con
  lógica, un converter, etc.) — probar es mejor que excluir. SOLO lo que de verdad NO se puede testear
  (puro cableado, constantes, enums, `@SpringBootApplication` main) se excluye de `sonar.coverage.exclusions`
  (no de `sonar.exclusions`) para que no salga en 0%. La decisión FINAL se toma en el paso 5 mirando el
  reporte. NO excluyas dominio/aplicación/adaptadores con lógica: eso se prueba.

## 3) Generar las pruebas (meta: >= 85%, ideal 100%)
- JUnit 5 + Mockito. Slice correcto según la capa hexagonal:
    - dominio/casos de uso -> pruebas unitarias puras (sin Spring), mockeando los PUERTOS de salida.
    - adaptadores de entrada REST -> `@WebMvcTest`; WebFlux -> `WebTestClient`.
    - adaptadores de salida -> mockea Connection/cliente; repos JPA -> `@DataJpaTest`/H2 si aplica.
- Patrón AAA, aserciones reales. Cubre caminos felices y de error, y ramas (if/else, switch, catch, null).
- No gastes pruebas en lo EXCLUIDO (SOAP generado).

## 4) Correr pruebas + JaCoCo y LEER los resultados
- Corre con el gradle y JDK locales:
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"
- Cuando TODAS pasen, LEE el reporte `build/reports/jacoco/test/html/index.html` (o el
  `jacocoTestReport.xml`). Si no está, pide la RUTA y léelo en ese momento.

## 5) Mirar las clases en 0%, clasificarlas y excluir solo lo que corresponde (y re-verificar)
- En el reporte, LOCALIZA las clases en 0% (o muy bajas). Para CADA una decide:
  * código GENERADO por el SOAP -> exclúyela.
  * pura CONFIGURACIÓN / sin lógica (config, `@SpringBootApplication` main, constantes, enums) -> exclúyela.
  * con lógica (dominio/aplicación/adaptadores) -> NO la excluyas: AGRÉGALE pruebas.
- Lo que toque excluir, agrégalo al `exclude` del bloque `jacocoTestReport` del `build.gradle` (mismo
  formato de ruta, paquete real del `build.gradle`/`contexto`, no ejemplos) y a `sonar.coverage.exclusions`.
- VUELVE a correr `test jacocoTestReport` y VERIFICA en el reporte (`build/reports/jacoco/test/html/index.html`)
  que las clases que excluiste (SOAP y configuración) ya NO aparecen y que la cobertura refleja el
  cambio. Si alguna sigue, revisa la ruta del `exclude` y repite hasta que quede excluida.
- NO excluyas tu propio código con lógica (dominio/aplicación/adaptadores) para inflar cobertura: si
  una clase propia queda baja, AGREGA pruebas.

## Entrega
- Qué se excluyó (sonar-project.properties y jacocoTestReport) y por qué.
- Dependencias de test agregadas (solo test) y por qué.
- Pruebas generadas (código completo) y cobertura final; qué falta para el 85% si no se llegó.
- Jamás `git push`/commit/PR.
