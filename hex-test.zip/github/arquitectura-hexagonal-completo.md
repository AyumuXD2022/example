# INSTRUCCIONES COMPLETAS — Migración a Arquitectura Hexagonal (todo en uno)

Pega este archivo COMPLETO en Copilot Chat con #file: y pídele que lo aplique.
Flujo de 5 pasos: contexto -> limpieza -> hexagonal (+diagrama) -> documentar -> test.
NUNCA hace git commit/push/PR en NINGÚN paso.

============================================================
## BASE (aplica siempre) + Entorno
============================================================

## Rol
Actúa como ARQUITECTO/DESARROLLADOR SENIOR Java / Spring Boot. Respondes en español, te basas en el
código REAL. No inventes. Tu objetivo es reorganizar el proyecto a HEXAGONAL conservando EXACTAMENTE
la misma funcionalidad de negocio.

## Reglas globales (OBLIGATORIAS en todos los pasos)
- ANTES de agregar CUALQUIER código o dependencia, LEE el `build.gradle` (y el BOM). Usa SOLO
  librerías/APIs que el proyecto YA tiene. NO pongas código de una dependencia que NO existe. Si de
  verdad hace falta una nueva, DILO y deja que la persona decida (excepción: dependencias de TEST en
  el paso 5).
- NO cambies la FUNCIONALIDAD DE NEGOCIO: el comportamiento observable debe quedar idéntico. Mover y
  reorganizar sí; cambiar lo que hace el código, no. Todo con ANTES/DESPUÉS.
- NUNCA descargues Gradle ni el JDK (ver "## Entorno"). Usa el Gradle y el JDK locales.
- NUNCA ejecutes `git add`, `git commit`, `git push` ni abras Pull Request, en NINGÚN paso. El commit
  lo hace la persona.
- Lo dudoso márcalo "A revisar" y explícalo; no lo cambies a ciegas.

## Entorno (nunca descargar Gradle ni el JDK)
- GRADLE: lee la versión en `gradle/wrapper/gradle-wrapper.properties` (campo `distributionUrl`) y
  DÍSELA a la persona (ej. "usa Gradle 8.14.3"). Luego pídele SOLO la RUTA/carpeta de ESA versión
  (ej. `C:\gradle\gradle-8.14.3`). TÚ completas el ejecutable (`\bin\gradle.bat` / `/bin/gradle`) y el
  comando con `--offline`. No uses `./gradlew` (baja la distribución).
- JDK: lee la versión de Java del `build.gradle` (`java { toolchain { languageVersion } }` o
  `sourceCompatibility`) y DÍSELA (ej. "usa Java 21"). Pídele SOLO la RUTA del JDK. NO uses `JAVA_HOME`:
  corre con `-Dorg.gradle.java.home="<ruta_del_jdk>"`. TÚ armas el comando.
- Comando de referencia:
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"

============================================================
## /contexto
============================================================


# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y entiende cómo funciona. NO cambies nada aquí.
Trabaja con el código REAL, no inventes. Si el repo es grande, ve por paquetes y DI cuáles revisaste.

## Entorno (no descargues nada)
- Lee la versión de Gradle (`gradle-wrapper.properties`) y la de Java (`build.gradle`) y DÍSELAS a la
  persona (ej. "usa Gradle 8.14.3 y Java 21"). Pídele SOLO las RUTAS locales de esas versiones.
- Con esas rutas, indaga qué necesita el proyecto para compilar/correr en local (JDK correcto,
  `--offline`, etc.). TÚ armas los comandos; no uses `JAVA_HOME` ni `./gradlew`.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> proceso -> salida.
2. **Arquitectura ACTUAL**: cómo está organizado hoy (capas, paquetes). Identifica el estilo
   (MVC por capas, service/repository, "todo junto", etc.) y dibuja el mapa de paquetes.
3. **¿Base de datos?** motor y cómo accede (JPA/Hibernate, JdbcTemplate, Connection), entidades y
   queries principales.
4. **¿SOAP?** endpoint/WSDL y CON QUÉ HERRAMIENTA se generaron las clases (wsimport, CXF wsdl2java,
   Axis, xjc) y en qué PAQUETE quedan.
5. **¿REST o WebFlux?** si expone/consume REST (Spring MVC) o usa WebFlux/Reactor; con qué clientes
   (RestTemplate, WebClient, Feign).
6. **Generadores de clases**: LISTA TODAS las herramientas que generen clases (wsimport, xjc,
   wsdl2java, Axis), con su task del `build.gradle` y su paquete de salida. Ponlas TODAS.
7. **Config relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.

## Entrega
- Resumen en español + tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`.
- Un mapa de la ARQUITECTURA ACTUAL (lista de paquetes/capas y qué hay en cada uno). Guarda esto:
  será la base del paso `/hexagonal` y del `/documentar`.
- Marca "A revisar" lo que no pudiste confirmar.

RECUERDA (base): jamás `git push`/commit/PR; no agregues código de dependencias que no estén en el
`build.gradle`; no cambies funcionalidad de negocio.

Cuando termines, ejecuta `/limpieza`.

============================================================
## /limpieza
============================================================


# PASO 2 — Limpieza de código

ANTES DE EMPEZAR: LEE el `build.gradle` (y el BOM) para saber qué dependencias tiene el proyecto y
qué VERSIÓN DE JAVA usa (`java { toolchain { languageVersion } }` o `sourceCompatibility`). NO uses
APIs/clases de una librería que el proyecto NO tiene; básate SOLO en lo presente. Y APÉGATE a esa
versión de Java: no introduzcas sintaxis/APIs de una versión más nueva (JDK 8: nada de `var`,
`records`, switch expression, `List.of`, text blocks; JDK 11: nada posterior). Debe seguir compilando
con esa versión; si no la sabes, pregúntala.

Haces dos cosas, SIEMPRE con la MISMA funcionalidad y con ANTES/DESPUÉS:
1) ELIMINAR lo que no se usa: clases y métodos muertos, variables/campos/parámetros e imports sin
   usar, `import *` -> explícitos, código comentado. No toques el código generado (SOAP).
2) SIMPLIFICAR el código que sí se usa: dejarlo MÁS SIMPLE y legible pero con EXACTAMENTE el mismo
   resultado y comportamiento (booleanos redundantes, `else` tras `return`, `if` anidados que se unen
   con `&&`, operador diamante, casts redundantes, `try-with-resources`, duplicados a método privado).

ANTES de simplificar un método, LEE y ENTIENDE qué hace. Solo simplifícalo si queda más simple y
legible SIN cambiar lo que hace. Si un método NO se puede simplificar sin arriesgar su comportamiento,
NO pasa nada: déjalo tal cual. Nunca fuerces una simplificación; siempre el camino seguro que NO afecte
la funcionalidad.

## Seguro
- Para afirmar que algo no se usa, búscalo (`usages`/`search`); si no puedes verlo, NO lo borres.
- Cuidado con Spring/reflexión/JPA/serialización/endpoints. Ante CUALQUIER duda, "A revisar".
- No renombres API pública ni cambies firmas. Nada que cambie resultado o comportamiento observable.

## Documentar (obligatorio en este paso)
- Entrega una lista de TODOS los cambios hechos: archivo, qué se eliminó o simplificó y por qué,
  con ANTES/DESPUÉS. Esto queda como registro del paso.
- Verifica que COMPILE (gradle/JDK locales) y que las pruebas sigan pasando.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hexagonal`.

============================================================
## /hexagonal
============================================================


# PASO 3 — Migrar a Arquitectura Hexagonal (Ports & Adapters)

Toma la ARQUITECTURA ACTUAL documentada en `/contexto` y reorganiza el proyecto a HEXAGONAL,
conservando EXACTAMENTE la misma funcionalidad de negocio (mismo comportamiento observable). Esto es
REESTRUCTURAR (mover código y crear puertos/adaptadores), NO reescribir la lógica.

## Capas y qué va en cada una
- **domain** (núcleo): entidades/modelos de negocio, value objects, reglas y servicios de dominio.
  NO depende de Spring, ni de JPA, ni de SOAP/REST. Aquí viven también los **puertos** (interfaces):
    - puertos de ENTRADA (casos de uso): qué puede pedirse al negocio.
    - puertos de SALIDA (repositorios/clientes): qué necesita el negocio del exterior.
- **application** (casos de uso): orquesta el dominio implementando los puertos de entrada. Sin
  detalles de framework; depende solo de `domain`.
- **infrastructure / adapters** (lo de afuera):
    - adaptadores de ENTRADA: controllers REST (Spring MVC) o handlers WebFlux, listeners, endpoints SOAP.
    - adaptadores de SALIDA: implementaciones JPA/JdbcTemplate de los repositorios, clientes REST/SOAP
      (RestTemplate/WebClient/puertos JAX-WS), colas.
    - configuración de Spring (`@Configuration`, beans), mapeos DTO<->dominio.
- El código GENERADO por el SOAP (wsimport/xjc) se queda como está y se usa SOLO desde el adaptador
  de salida SOAP; no lo metas al dominio.

## Reglas de dependencia (clave del hexagonal)
- Las dependencias apuntan HACIA ADENTRO: infrastructure -> application -> domain. El dominio NO
  conoce a nadie de afuera.
- La comunicación con el exterior pasa SIEMPRE por un PUERTO (interfaz) y su ADAPTADOR.
- Mantén la misma funcionalidad: cada caso de uso debe producir el mismo resultado que hoy.

## Cómo hacerlo (seguro, por pasos)
1) Propón la nueva estructura de paquetes (domain/application/infrastructure) y MUÉSTRALA antes de mover.
2) Extrae interfaces (puertos) para lo que hoy son services/repositories; haz que las clases actuales
   pasen a ser adaptadores que las implementan.
3) Mueve el código a su capa, ajustando imports/paquetes. Usa SOLO dependencias ya presentes en el
   `build.gradle` (no agregues librerías nuevas sin avisar).
4) Conserva las firmas públicas y el comportamiento; si algo obliga a decidir, márcalo "A revisar".
5) Verifica que COMPILE y que las pruebas existentes sigan pasando (gradle/JDK locales).

## Diagrama al finalizar (obligatorio)
Entrega un diagrama de cómo quedó, en **Mermaid**, mostrando capas, puertos y adaptadores, y las
CLASES reales que ubicaste en cada una (las que leíste) con su funcionalidad. Ejemplo de forma:

```mermaid
flowchart TB
  subgraph Infra_In[Adaptadores de entrada]
    REST[XxxController (REST)]
    SOAPIN[XxxEndpoint (SOAP)]
  end
  subgraph App[Application - Casos de uso]
    UC[XxxUseCase impl]
  end
  subgraph Domain[Domain - Núcleo]
    MODEL[Xxx (modelo)]
    PIN[[Puerto entrada: XxxService]]
    POUT[[Puerto salida: XxxRepository]]
  end
  subgraph Infra_Out[Adaptadores de salida]
    JPA[XxxRepositoryJpa]
    SOAPCLI[XxxSoapClient]
  end
  REST --> PIN
  SOAPIN --> PIN
  PIN --> UC --> MODEL
  UC --> POUT
  POUT --> JPA
  POUT --> SOAPCLI
```

Acompaña el diagrama con una tabla `| Clase | Capa | Rol (puerto/adaptador/modelo/caso de uso) | Qué hace |`.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/documentar`.

============================================================
## /documentar
============================================================


# PASO 4 — Documentar el cambio de arquitectura

Genera la documentación que compara la arquitectura ANTES (la de `/contexto`) con la nueva
arquitectura HEXAGONAL (la de `/hexagonal`). No cambies código aquí; solo documentas.

## Qué entregar
1. **Resumen del cambio**: en 1-2 párrafos, qué se reorganizó y por qué (el negocio quedó igual).
2. **Antes vs Después (estructura)**: tabla o dos árboles de paquetes:
   - Árbol de paquetes ANTES.
   - Árbol de paquetes DESPUÉS (domain / application / infrastructure).
3. **Mapa de movimientos por clase**: tabla
   `| Clase | Ubicación ANTES | Ubicación DESPUÉS | Capa | Rol (puerto/adaptador/modelo/caso de uso) |`.
4. **Puertos y adaptadores creados**: lista de interfaces (puertos de entrada/salida) nuevas y qué
   clase las implementa (adaptador).
5. **Qué NO cambió**: deja claro que la funcionalidad de negocio es la misma (mismos resultados,
   mismos endpoints/contratos). Si algo quedó "A revisar", lístalo.
6. **Diagramas**: incluye el diagrama Mermaid del hexagonal (del paso 3) y, si ayuda, un diagrama
   simple del "antes" para comparar.

Formato: Markdown claro (sirve para un README o una wiki). No inventes; básate en lo que realmente
moviste y leíste.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/test`.

============================================================
## /test
============================================================


# PASO 5 — Pruebas, cobertura y exclusiones

## 1) Dependencias de prueba (lee el build.gradle primero)
- PRIMERO LEE el `build.gradle` para ver qué dependencias ya existen (no dupliques) y en qué scope.
- Si faltan dependencias para poder probar, AGRÉGALAS pero SOLO de ámbito de PRUEBA
  (`testImplementation` / `testRuntimeOnly` / `testCompileOnly` / `testAnnotationProcessor`). NUNCA
  toques producción. Usa SOLO APIs de dependencias que estén en el `build.gradle`; no pongas código de
  una librería que no existe. Reporta qué agregaste y por qué.
- Nombres correctos (OJO con los que NO existen):
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc'  -> MVC va en 'spring-boot-starter-web'
    * NO existe 'org.springframework.boot:spring-boot-starter-security-test'
         -> es 'org.springframework.security:spring-security-test'
    * @WebMvcTest/MockMvc ya vienen en 'org.springframework.boot:spring-boot-starter-test'
- Base: `testImplementation 'org.springframework.boot:spring-boot-starter-test'` +
  `testRuntimeOnly 'org.junit.platform:junit-platform-launcher'`.

## 2) Exclusiones en sonar-project.properties (NO lo crees — YA existe)
- El proyecto YA tiene su `sonar-project.properties`. NUNCA lo crees ni lo reestructures.
- Solo ÁBRELO y mira `sonar.exclusions` y `sonar.coverage.exclusions`. AGREGA ahí la(s) clase(s)
  GENERADA(S) por el SOAP (wsimport/xjc/wsdl2java detectado en `/contexto`) para EXCLUIRLAS, con el
  MISMO formato de rutas que ya use el archivo, sin borrar lo demás. No excluyas tu código de negocio.

## 3) Generar las pruebas (meta: >= 85%, ideal 100%)
- JUnit 5 + Mockito. Slice correcto según la capa hexagonal:
    - dominio/casos de uso -> pruebas unitarias puras (sin Spring), mockeando los PUERTOS de salida.
    - adaptadores de entrada REST -> `@WebMvcTest`; WebFlux -> `WebTestClient`.
    - adaptadores de salida -> mockea Connection/cliente; repos JPA -> `@DataJpaTest`/H2 si aplica.
- Patrón AAA, aserciones reales. Cubre caminos felices y de error, y ramas (if/else, switch, catch, null).
- No gastes pruebas en lo EXCLUIDO (SOAP generado).

## 4) Correr pruebas + JaCoCo y LEER los resultados
- Corre con el gradle y JDK locales:
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"
- Cuando TODAS pasen, LEE el reporte `build/reports/jacoco/test/html/index.html` (o el
  `jacocoTestReport.xml`). Si no está, pide la RUTA y léelo en ese momento.

## 5) Quitar la clase generada por el SOAP también en JaCoCo y re-verificar
- Revisa en el reporte si la clase GENERADA por el SOAP sigue contando. Si sí, agrégala al `exclude`
  del bloque `jacocoTestReport` del `build.gradle`, con el MISMO formato de ruta, derivando el paquete
  real del `build.gradle` (task wsimport/xjc) o del `/contexto`. NO copies paquetes de ejemplo.
- VUELVE a correr `test jacocoTestReport` y VERIFICA en el reporte (`build/reports/jacoco/test/html/index.html`)
  que esa clase generada ya NO aparece y que la cobertura refleja el cambio.
- NO excluyas tu propio código (dominio/aplicación/adaptadores) para inflar cobertura: si una clase
  propia queda baja, AGREGA pruebas.

## Entrega
- Qué se excluyó (sonar-project.properties y jacocoTestReport) y por qué.
- Dependencias de test agregadas (solo test) y por qué.
- Pruebas generadas (código completo) y cobertura final; qué falta para el 85% si no se llegó.
- Jamás `git push`/commit/PR.
