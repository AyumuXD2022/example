---
mode: ask
description: "PASO 2 — Limpieza y simplificación sin cambiar funcionalidad (documenta los cambios)"
---

# PASO 2 — Limpieza de código

ANTES DE EMPEZAR: LEE el `build.gradle` (y el BOM) para saber qué dependencias tiene el proyecto y
qué VERSIÓN DE JAVA usa (`java { toolchain { languageVersion } }` o `sourceCompatibility`). NO uses
APIs/clases de una librería que el proyecto NO tiene; básate SOLO en lo presente. Y APÉGATE a esa
versión de Java: no introduzcas sintaxis/APIs de una versión más nueva (JDK 8: nada de `var`,
`records`, switch expression, `List.of`, text blocks; JDK 11: nada posterior). Debe seguir compilando
con esa versión; si no la sabes, pregúntala.

Haces dos cosas, SIEMPRE con la MISMA funcionalidad y con ANTES/DESPUÉS:
1) ELIMINAR lo que no se usa: clases y métodos muertos, variables/campos/parámetros e imports sin
   usar, `import *` -> explícitos, código comentado. No toques el código generado (SOAP).
2) SIMPLIFICAR el código que sí se usa: dejarlo MÁS SIMPLE y legible pero con EXACTAMENTE el mismo
   resultado y comportamiento (booleanos redundantes, `else` tras `return`, `if` anidados que se unen
   con `&&`, operador diamante, casts redundantes, `try-with-resources`, duplicados a método privado).

ANTES de simplificar un método, LEE y ENTIENDE qué hace. Solo simplifícalo si queda más simple y
legible SIN cambiar lo que hace. Si un método NO se puede simplificar sin arriesgar su comportamiento,
NO pasa nada: déjalo tal cual. Nunca fuerces una simplificación; siempre el camino seguro que NO afecte
la funcionalidad.

## Seguro
- Para afirmar que algo no se usa, búscalo (`usages`/`search`); si no puedes verlo, NO lo borres.
- Cuidado con Spring/reflexión/JPA/serialización/endpoints. Ante CUALQUIER duda, "A revisar".
- No renombres API pública ni cambies firmas. Nada que cambie resultado o comportamiento observable.

## Documentar (obligatorio en este paso)
- Entrega una lista de TODOS los cambios hechos: archivo, qué se eliminó o simplificó y por qué,
  con ANTES/DESPUÉS. Esto queda como registro del paso.
- Verifica que COMPILE (gradle/JDK locales) y que las pruebas sigan pasando.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hex-hexagonal`.
