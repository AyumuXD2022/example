---
mode: ask
description: "PASO 3 — Eliminar código muerto y simplificar SIN cambiar la funcionalidad"
---

# PASO 3 — Limpieza: eliminar código muerto y simplificar

ANTES DE EMPEZAR, según el tipo de proyecto (visto en `/rev-contexto`):
- Si NO es un Java Project (es Gradle/Maven): PRIMERO LEE el `build.gradle`/`pom.xml` (y el BOM) para
  saber qué dependencias tiene REALMENTE y qué versión de Java usa.
- Si ES un Java Project de Eclipse: usa la carpeta de `.jar` que te dieron como lista de dependencias
  y la versión de Java (JDK) que te indicaron.
En ambos casos: al simplificar NO uses APIs/clases de una librería que el proyecto NO tiene; básate
SOLO en las dependencias presentes (y en el JDK del proyecto). No metas imports ni utilidades de una
librería ausente (ej. Guava/Apache Commons/Lombok si no están). Si una simplificación necesitaría algo
que no está, NO la hagas (o dilo y deja que la persona decida).

LEE LA VERSIÓN DE JAVA y APÉGATE a ella:
- Si es proyecto GRADLE: léela en el `build.gradle` (`java { toolchain { languageVersion } }` o
  `sourceCompatibility`/`targetCompatibility`) y usa ESE nivel de JDK.
- Si es un Java Project de Eclipse: usa la versión de JDK que te indicó la persona (y la carpeta de `.jar`).
NO introduzcas sintaxis ni APIs de una versión MÁS NUEVA que esa: si es JDK 8, nada de `var`, `records`,
`switch` expression, `List.of`, text blocks, etc.; si es JDK 11, nada posterior a 11. El código debe
seguir compilando con ESA versión. Si no sabes la versión, PREGÚNTALA antes de simplificar.

Aquí haces dos cosas, SIEMPRE con el MISMO comportamiento (nada cambia de funcionalidad) y con
ANTES/DESPUÉS:
1) ELIMINAR lo que no se usa (clases y métodos muertos).
2) SIMPLIFICAR el código que sí se usa: dejarlo MÁS SIMPLE y legible pero con EXACTAMENTE la misma
   funcionalidad (mismo resultado y mismo comportamiento observable). Si no queda equivalente, no lo toques.

ANTES de simplificar un método, LEE y ENTIENDE qué hace (su funcionalidad). Solo simplifícalo si
queda más simple y legible SIN cambiar lo que hace. Si un método NO se puede simplificar sin arriesgar
su comportamiento, NO pasa nada: déjalo tal cual. Nunca fuerces una simplificación; siempre el camino
seguro que NO afecte la funcionalidad.

## Alcance (solo lo que ves)
- Analiza SOLO el código que tienes en contexto (archivos `#file:` o lo que trajo `@workspace`).
- Para afirmar que algo NO se usa, tienes que PODER ver dónde se usaría. Si no tienes esa
  visibilidad, NO borres: dilo y pide los archivos que faltan (o que agreguen `@workspace`).
- NO toques el código generado (wsimport/xjc/wsdl2java) detectado en `/rev-contexto`.

## Qué eliminar (si confirmas que no se usa)
- Clases que no se referencian en ningún lado.
- Métodos privados que nadie llama.
- Variables, campos y parámetros sin usar; imports sin usar.
- `import` con comodín (`import java.util.*;`) -> imports EXPLÍCITOS de lo que se usa.
- Código comentado que ya no sirve.

## Simplificar (sin cambiar el comportamiento)
Solo cambios SEGUROS y equivalentes, que no alteran lo que hace el código. Ejemplos permitidos:
- Booleanos redundantes: `if (x == true)` -> `if (x)`; `if (c) return true; else return false;` -> `return c;`.
- `else` innecesario después de un `return`/`throw`.
- `if` anidados que se pueden unir con `&&` cuando el resultado es idéntico.
- Variables locales usadas una sola vez que solo repiten un valor (inline), si queda más claro.
- Operador diamante `new ArrayList<>()`, quitar casts redundantes, imports/`this.` innecesarios.
- `try-with-resources` en lugar de cerrar manualmente en `finally` (mismo cierre, menos código).
- Condiciones u ramas IMPOSIBLES/duplicadas que nunca cambian el resultado.
- Unir código DUPLICADO en un método privado, SOLO si el comportamiento queda idéntico.
Reglas de la simplificación:
- Si existe CUALQUIER duda de que cambie el comportamiento (orden de efectos, null, excepciones,
  tipos, concurrencia), NO lo toques: márcalo "A revisar".
- No renombres API pública ni cambies firmas de métodos. No cambies el estilo por gusto.
- Nada de "optimizaciones" que cambien resultados o rendimiento observable.

## Cómo hacerlo (seguro)
1) LISTA primero lo detectado: lo muerto (clase/método, archivo:línea, por qué) y lo simplificable
   (qué y por qué queda equivalente).
2) Luego aplica/propón los cambios con ANTES/DESPUÉS, separando "eliminado" de "simplificado".
3) Mantén la lógica: el código debe hacer EXACTAMENTE lo mismo que antes.

## NO eliminar si hay duda
Puede estar vivo por vías que no se ven: inyección de Spring (`@Component/@Service/@Bean/@Autowired`),
reflexión, serialización (Jackson/JAXB), entidades/campos JPA, métodos públicos usados desde otro
módulo, endpoints, `main`, jobs. Ante CUALQUIER duda, NO borres: márcalo "A revisar".

## Después
- Verifica que COMPILE (con el gradle y JDK locales del PASO 2) y que las pruebas sigan pasando.
- Jamás `git push`/commit/PR.
- Cuando termines, ejecuta `/rev-checkmarx`.
