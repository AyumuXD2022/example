---
mode: ask
description: "PASO 1 — Leer TODO el proyecto y documentarlo (SOAP, generadores, REST/WebFlux, BD, arquitectura)"
---

# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y entiende cómo funciona. NO cambies nada aquí.
Trabaja con el código REAL, no inventes. Si el repo es grande, ve por paquetes y DI cuáles revisaste.

## COBERTURA DE LECTURA (dilo explícito)
- ENUMERA los paquetes/módulos de nivel alto y marca cuáles REVISASTE y cuáles NO alcanzaste a leer.
  Entrega: "Leídos: [...] / NO leídos (incompletos): [...]".
- Si hay paquetes NO leídos, AVISA que el mapa de flujo puede estar INCOMPLETO en esas zonas y
  recomienda revisarlos por módulo antes de que `/hex-limpieza` borre algo que dependa de ellos. Esas zonas
  van "A revisar", nunca "no".

## ANTES DE TERMINAR — pregunta obligatoria si quedó algo sin leer
- Si hay CLASES sin leer o leídas a MEDIAS, NO cierres el contexto: LÍSTALAS por nombre (clase + archivo)
  marcando "sin leer" / "incompleta".
- PREGUNTA a la persona: "¿Quieres que lea COMPLETAS estas clases (me enfoco en ellas e ignoro el resto),
  o sigo con lo ya leído aunque queden incompletas?"
- Si SÍ: pídeselas con `#file:` (o ábrelas), LÉELAS COMPLETAS e ignora lo demás; completa el mapa.
- Si NO (o no responde): déjalas "A revisar / incompleta" y dilo, para que `/hex-limpieza` no borre nada que
  dependa de ellas.

## Entorno (no descargues nada)
- Lee la versión de Gradle (`gradle-wrapper.properties`) y la de Java (`build.gradle`) y DÍSELAS a la
  persona (ej. "usa Gradle 8.14.3 y Java 21"). Pídele SOLO las RUTAS locales de esas versiones.
- Con esas rutas, indaga qué necesita el proyecto para compilar/correr en local (JDK correcto,
  `--offline`, etc.). TÚ armas los comandos; no uses `JAVA_HOME` ni `./gradlew`.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> proceso -> salida.
2. **Arquitectura ACTUAL**: cómo está organizado hoy (capas, paquetes). Identifica el estilo
   (MVC por capas, service/repository, "todo junto", etc.) y dibuja el mapa de paquetes.
3. **¿Base de datos?** motor y cómo accede (JPA/Hibernate, JdbcTemplate, Connection), entidades y
   queries principales.
4. **¿SOAP?** endpoint/WSDL y CON QUÉ HERRAMIENTA se generaron las clases (wsimport, CXF wsdl2java,
   Axis, xjc) y en qué PAQUETE quedan.
5. **¿REST o WebFlux?** si expone/consume REST (Spring MVC) o usa WebFlux/Reactor; con qué clientes
   (RestTemplate, WebClient, Feign).
6. **Generadores de clases**: LISTA TODAS las herramientas que generen clases (wsimport, xjc,
   wsdl2java, Axis), con su task del `build.gradle` y su paquete de salida. Ponlas TODAS.
7. **Config relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.
8. **CONFIGURACIÓN DE SEGURIDAD:** ¿hay? (Spring Security, filtros, JWT, WS-Security). Di qué clases la
   forman -> FORMAN PARTE DEL FLUJO, NO son muertas. Márcalas "en el flujo".
9. **CONFIGURACIÓN DE SOAP y CÓDIGO GENERADO:** ¿hay config de SOAP? (endpoint/cliente, CXF/JAX-WS, WSDL)
   -> parte del flujo. Identifica el PAQUETE de las clases GENERADAS por SOAP (wsimport/xjc/wsdl2java):
   NO todas se usan y eso es NORMAL; ese código NO se elimina. Marca el paquete "GENERADO — NO ELIMINAR".
10. **LÓGICA DE NEGOCIO Y FLUJO (importante para la limpieza):**
   - Traza el/los FLUJO(S) principal(es): del punto de entrada (controller/endpoint/listener/`main`) a
     la salida (BD, otro servicio, respuesta), pasando por services/clientes/utilidades.
   - Di dónde está la LÓGICA DE NEGOCIO real (reglas, cálculos, validaciones) y en qué clases/métodos.
   - CLASIFICA cada clase: ¿está EN el flujo o NO? (ojo: puede estar viva por Spring/reflexión/JPA/endpoints;
     y la config de seguridad/SOAP y TODO el generado por SOAP cuentan como "en el flujo / no eliminar").

## Entrega
- Resumen en español + tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`.
- Un mapa de la ARQUITECTURA ACTUAL (lista de paquetes/capas y qué hay en cada uno). Guarda esto:
  será la base del paso `/hex-hexagonal` y del `/hex-documentar`.
- Un MAPA DE FLUJO / clases: `| Clase | ¿En el flujo? (sí/no/A revisar) | Rol en el negocio | Quién la usa |`.
  Es la BASE de `/hex-limpieza`. Lo que no puedas confirmar que NO se usa -> "A revisar", no "no".
- Un DIAGRAMA DEL FLUJO en **Mermaid** (`flowchart`): del punto de entrada a la salida con las clases
  reales por las que pasa (controller -> service -> repositorio/cliente -> BD/SOAP/REST). Nombres reales,
  no inventes. (Es el flujo ACTUAL; el diagrama hexagonal se hace luego en `/hex-hexagonal`.)
- Marca "A revisar" lo que no pudiste confirmar.

RECUERDA (base): jamás `git push`/commit/PR; no agregues código de dependencias que no estén en el
`build.gradle`; no cambies funcionalidad de negocio.

Cuando termines, ejecuta `/hex-limpieza`.
