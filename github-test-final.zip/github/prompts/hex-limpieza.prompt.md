---
mode: ask
description: "PASO 2 — Limpieza y simplificación sin cambiar funcionalidad (documenta los cambios)"
---

# PASO 2 — Limpieza de código

ANTES DE EMPEZAR: LEE el `build.gradle` (y el BOM) para saber qué dependencias tiene el proyecto y
qué VERSIÓN DE JAVA usa (`java { toolchain { languageVersion } }` o `sourceCompatibility`). NO uses
APIs/clases de una librería que el proyecto NO tiene; básate SOLO en lo presente. Y APÉGATE a esa
versión de Java: no introduzcas sintaxis/APIs de una versión más nueva (JDK 8: nada de `var`,
`records`, switch expression, `List.of`, text blocks; JDK 11: nada posterior). Debe seguir compilando
con esa versión; si no la sabes, pregúntala.

## Orden de trabajo (hazlo en este orden), SIEMPRE con la MISMA funcionalidad y con ANTES/DESPUÉS
0) APÓYATE EN EL MAPA DE FLUJO / LÓGICA DE NEGOCIO de `/hex-contexto` (qué clases están EN el flujo y cuáles
   NO, y dónde está la lógica real). Ese mapa decide qué se puede quitar. Ya tienes del inicio las
   dependencias y la versión de Java a la que apegarte.
1) MÉTODOS MUERTOS primero: mirando el flujo/lógica de negocio, elimina los MÉTODOS que no participan en
   el negocio y que nadie del flujo llama; igual variables/parámetros/imports sin usar, `import *` ->
   explícitos, y código comentado. (Cascada: ver abajo.) No toques el código generado (SOAP).
2) SIMPLIFICA el código que SÍ se usa (el del flujo/negocio): más simple y legible pero con EXACTAMENTE
   la misma funcionalidad (booleanos redundantes, `else` tras `return`, `if` con `&&`, operador diamante,
   casts redundantes, `try-with-resources`, duplicados a método privado). ANTES de simplificar un método
   ENTIENDE qué hace; si NO se puede sin arriesgar el comportamiento, déjalo igual (no pasa nada).
3) AL FINAL, ELIMINA LAS CLASES que NO están en el flujo ni en la lógica de negocio (las que el mapa de
   `/hex-contexto` marcó "no"). Aplica la cascada. Para DTO/Entity (y model/vo/pojo):
   - clase DTO/Entity que NO está en el flujo -> elimínala.
   - clase DTO/Entity que SÍ está en el flujo -> DÉJALA TAL CUAL, NO le quites atributos aunque parezcan
     sin usar (un campo suele mapear BD/JSON o usarse por reflexión).
   - clase marcada "A revisar" en el mapa -> NO la borres.
   - NUNCA elimines el código GENERADO por SOAP (wsimport/xjc/wsdl2java) aunque algunas clases no se usen
     (es normal), ni las clases de CONFIGURACIÓN de SEGURIDAD o de SOAP (están "en el flujo").

## Imports explícitos (no nombres cualificados en el cuerpo)
- Si un tipo está escrito con su paquete completo, p. ej. `private com.mx.entity.Clase clase;`,
  cámbialo por un IMPORT explícito arriba + nombre SIMPLE: `import com.mx.entity.Clase;` y `private Clase clase;`.
- CHOQUE DE NOMBRES: si en el MISMO archivo se usan DOS clases distintas con el mismo nombre simple,
  no se pueden importar las dos. Entonces RENOMBRA una de las clases a un nombre claro y distinto, pon
  los imports explícitos de ambas, actualiza TODOS los usos y DOCUMENTA el antes -> después (archivo de
  la clase y dónde se usaba). Luego VERIFICA que compile. NO renombres el código GENERADO (SOAP) ni API
  pública consumida fuera del proyecto; en ese caso renombra la OTRA, y si ninguna se puede sin riesgo,
  déjalo con el paquete completo y dilo.
- Es cosmético/legibilidad: NO cambia la funcionalidad.

## Código muerto EN CASCADA
- Una referencia que viene de código MUERTO no cuenta como "uso". Si `A` usa a `B` pero `A` NO se usa
  en ningún lado, entonces `B` queda sin uso real: elimina las DOS.
- Hazlo en CASCADA: tras borrar una clase/método muerto, revisa lo que usaba; si quedó sin uso real,
  bórralo también. Repite hasta que no quede nada que solo dependiera de lo ya eliminado.
- NO aplica a DTO/Entity que SÍ se usan (no se tocan sus atributos).

## Seguro
- Para afirmar que algo no se usa, búscalo (`usages`/`search`); si no puedes verlo, NO lo borres.
- Cuidado con Spring/reflexión/JPA/serialización/endpoints. Ante CUALQUIER duda, "A revisar".
- No renombres API pública ni cambies firmas. Nada que cambie resultado o comportamiento observable.

## Cómo trabajar (OBLIGATORIO — para que sea lo más confiable posible)
1) POR PAQUETE/MÓDULO, no todo el repo de un jalón. Limpia UN paquete completo (métodos -> simplificar
   -> clases), compila y corre pruebas, y SOLO cuando pase sigue con el siguiente. Así ve bien los usos.
2) ANTES de eliminar CLASES, NO borres nada: entrega una TABLA con las clases candidatas y PIDE confirmación:
   `| Clase | Ubicación (archivo/paquete) | ¿En el flujo de negocio? (sí/no) | Motivo de eliminación |`
   - Para las candidatas pon "no" y el motivo (no es seguridad/SOAP/config y nadie del flujo la usa). Lo
     que no estés seguro va "A revisar", NO como candidato.
   - La persona confirma qué filas eliminar; solo borra las aprobadas. Si no responde, no borras nada.
3) NINGÚN cambio se da por bueno sin COMPILAR y que PASEN LAS PRUEBAS. Tras cada paquete corre
   `"<ruta_gradle>\bin\gradle.bat" clean test --offline -Dorg.gradle.java.home="<ruta_jdk>"`.
   Si algo se rompe por tu cambio -> REVIÉRTELO y repórtalo; no sigas mientras algo esté roto.

## Documentar (obligatorio en este paso)
- Entrega una lista de TODOS los cambios hechos: archivo, qué se eliminó o simplificó y por qué,
  con ANTES/DESPUÉS, y qué quedó "A revisar". Esto queda como registro del paso.
- Confirma que COMPILA y que TODAS las pruebas pasan (gradle/JDK locales).

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hex-hexagonal`.
