---
mode: ask
description: "PASO 3 — Eliminar código muerto y simplificar SIN cambiar la funcionalidad"
---

# PASO 3 — Limpieza: eliminar código muerto y simplificar

ANTES DE EMPEZAR, según el tipo de proyecto (visto en `/rev-contexto`):
- Si NO es un Java Project (es Gradle/Maven): PRIMERO LEE el `build.gradle`/`pom.xml` (y el BOM) para
  saber qué dependencias tiene REALMENTE y qué versión de Java usa.
- Si ES un Java Project de Eclipse: usa la carpeta de `.jar` que te dieron como lista de dependencias
  y la versión de Java (JDK) que te indicaron.
En ambos casos: al simplificar NO uses APIs/clases de una librería que el proyecto NO tiene; básate
SOLO en las dependencias presentes (y en el JDK del proyecto). No metas imports ni utilidades de una
librería ausente (ej. Guava/Apache Commons/Lombok si no están). Si una simplificación necesitaría algo
que no está, NO la hagas (o dilo y deja que la persona decida).

LEE LA VERSIÓN DE JAVA y APÉGATE a ella:
- Si es proyecto GRADLE: léela en el `build.gradle` (`java { toolchain { languageVersion } }` o
  `sourceCompatibility`/`targetCompatibility`) y usa ESE nivel de JDK.
- Si es un Java Project de Eclipse: usa la versión de JDK que te indicó la persona (y la carpeta de `.jar`).
NO introduzcas sintaxis ni APIs de una versión MÁS NUEVA que esa: si es JDK 8, nada de `var`, `records`,
`switch` expression, `List.of`, text blocks, etc.; si es JDK 11, nada posterior a 11. El código debe
seguir compilando con ESA versión. Si no sabes la versión, PREGÚNTALA antes de simplificar.

Aquí haces dos cosas, SIEMPRE con el MISMO comportamiento (nada cambia de funcionalidad) y con
ANTES/DESPUÉS:
1) ELIMINAR lo que no se usa (clases y métodos muertos).
2) SIMPLIFICAR el código que sí se usa: dejarlo MÁS SIMPLE y legible pero con EXACTAMENTE la misma
   funcionalidad (mismo resultado y mismo comportamiento observable). Si no queda equivalente, no lo toques.

ANTES de simplificar un método, LEE y ENTIENDE qué hace (su funcionalidad). Solo simplifícalo si
queda más simple y legible SIN cambiar lo que hace. Si un método NO se puede simplificar sin arriesgar
su comportamiento, NO pasa nada: déjalo tal cual. Nunca fuerces una simplificación; siempre el camino
seguro que NO afecte la funcionalidad.

## Alcance (solo lo que ves)
- Analiza SOLO el código que tienes en contexto (archivos `#file:` o lo que trajo `@workspace`).
- Para afirmar que algo NO se usa, tienes que PODER ver dónde se usaría. Si no tienes esa
  visibilidad, NO borres: dilo y pide los archivos que faltan (o que agreguen `@workspace`).
- NO toques el código generado (wsimport/xjc/wsdl2java) detectado en `/rev-contexto`.

## Qué eliminar (si confirmas que no se usa)
- Clases que no se referencian en ningún lado.
- Métodos privados que nadie llama.
- Variables, campos y parámetros sin usar; imports sin usar.
- `import` con comodín (`import java.util.*;`) -> imports EXPLÍCITOS de lo que se usa.
- Código comentado que ya no sirve.

## Simplificar (sin cambiar el comportamiento)
Solo cambios SEGUROS y equivalentes, que no alteran lo que hace el código. Ejemplos permitidos:
- Booleanos redundantes: `if (x == true)` -> `if (x)`; `if (c) return true; else return false;` -> `return c;`.
- `else` innecesario después de un `return`/`throw`.
- `if` anidados que se pueden unir con `&&` cuando el resultado es idéntico.
- Variables locales usadas una sola vez que solo repiten un valor (inline), si queda más claro.
- Operador diamante `new ArrayList<>()`, quitar casts redundantes, imports/`this.` innecesarios.
- `try-with-resources` en lugar de cerrar manualmente en `finally` (mismo cierre, menos código).
- Condiciones u ramas IMPOSIBLES/duplicadas que nunca cambian el resultado.
- Unir código DUPLICADO en un método privado, SOLO si el comportamiento queda idéntico.
Reglas de la simplificación:
- Si existe CUALQUIER duda de que cambie el comportamiento (orden de efectos, null, excepciones,
  tipos, concurrencia), NO lo toques: márcalo "A revisar".
- No renombres API pública ni cambies firmas de métodos. No cambies el estilo por gusto.
- Nada de "optimizaciones" que cambien resultados o rendimiento observable.

## Orden de trabajo (hazlo en este orden)
0) APÓYATE EN EL MAPA DE FLUJO / LÓGICA DE NEGOCIO que hizo `/rev-contexto` (qué clases están EN el flujo y
   cuáles NO, y dónde está la lógica real). Ese mapa decide qué se puede quitar. Y ya tienes del inicio
   las dependencias y la versión de Java a la que apegarte.

1) MÉTODOS MUERTOS primero: mirando el flujo/lógica de negocio, elimina los MÉTODOS que no participan en
   el negocio y que nadie del flujo llama. Igual variables/parámetros/imports sin usar, `import *` ->
   explícitos, y código comentado muerto. (Cascada: ver abajo.) No toques el código generado (SOAP).

2) SIMPLIFICA el código que SÍ se usa (el del flujo/negocio): déjalo más simple y legible pero con
   EXACTAMENTE la misma funcionalidad. ANTES de simplificar un método, entiende qué hace. Si un trozo
   NO se puede simplificar sin arriesgar el comportamiento, NO pasa nada: déjalo igual.

3) AL FINAL, ELIMINA LAS CLASES que NO están en el flujo ni en la lógica de negocio (las que el mapa de
   `/rev-contexto` marcó "no"). Aplica la cascada. Para DTO/Entity (y model/vo/pojo):
   - clase DTO/Entity que NO está en el flujo -> elimínala.
   - clase DTO/Entity que SÍ está en el flujo -> DÉJALA TAL CUAL, NO le quites atributos aunque parezcan
     sin usar (un campo suele mapear BD/JSON o usarse por reflexión).
   - Si una clase está marcada "A revisar" en el mapa (no se pudo confirmar que no se usa), NO la borres.
   - NUNCA elimines el código GENERADO por SOAP (wsimport/xjc/wsdl2java), AUNQUE algunas clases generadas
     no se usen: en un proyecto con SOAP eso es NORMAL y ese paquete no se toca. Tampoco elimines las
     clases de CONFIGURACIÓN de SEGURIDAD ni de SOAP (están "en el flujo" aunque no se vean llamadas).

## Imports explícitos (no nombres cualificados en el cuerpo)
- Si en el código hay un tipo escrito con su paquete completo, p. ej.
  `private com.mx.entity.Clase clase;` o `com.mx.entity.Clase x = new com.mx.entity.Clase();`,
  cámbialo por un IMPORT explícito arriba y el nombre SIMPLE en el cuerpo:
      import com.mx.entity.Clase;
      ...
      private Clase clase;
- CHOQUE DE NOMBRES: si en ese MISMO archivo se usan DOS clases distintas con el MISMO nombre simple
  (ej. `com.mx.entity.Clase` y `com.otro.Clase`), no se pueden importar las dos. Entonces RENOMBRA una
  de las clases a un nombre claro y distinto, pon los imports explícitos de ambas y actualiza TODOS los
  usos. DOCUMENTA el cambio: nombre ANTES -> DESPUÉS, el archivo de la clase y en qué archivos se usaba.
  Luego VERIFICA que compile.
  Seguridad al renombrar: NO renombres el código GENERADO (SOAP/wsimport/xjc) ni una clase que sea API
  pública consumida FUERA de este proyecto; en esos casos renombra la OTRA. Si ninguna se puede
  renombrar sin riesgo, déjalo con el paquete completo y dilo.
- El cambio de import es cosmético; el renombrado ajusta nombre y usos pero NO cambia la funcionalidad.

## Código muerto EN CASCADA (importante)
- Una referencia que viene de código MUERTO no cuenta como "uso". Si la clase `A` usa a la clase `B`,
  pero `A` NO se usa en ningún lado (está muerta), entonces `B` queda sin uso real: elimina las DOS.
- Trabaja en CASCADA: después de borrar una clase/método muerto, VUELVE a revisar lo que esa clase/
  método usaba; si quedó sin uso real (solo lo llamaba lo que acabas de borrar), bórralo también.
  Repite hasta que no quede nada que solo dependiera de código ya eliminado.
- Esto NO aplica a DTO/Entity que SÍ se usan (a esos no se les tocan atributos). Y mantén el candado:
  si algo puede estar vivo por Spring/reflexión/JPA/endpoints, no lo borres (márcalo "A revisar").

En cada punto: LISTA primero lo detectado (archivo:línea y por qué) y aplica con ANTES/DESPUÉS,
separando "eliminado" de "simplificado". El código debe hacer EXACTAMENTE lo mismo que antes.

## NO eliminar si hay duda
Puede estar vivo por vías que no se ven: inyección de Spring (`@Component/@Service/@Bean/@Autowired`),
reflexión, serialización (Jackson/JAXB), entidades/campos JPA, métodos públicos usados desde otro
módulo, endpoints, `main`, jobs. Ante CUALQUIER duda, NO borres: márcalo "A revisar".

## Cómo trabajar (OBLIGATORIO — para que sea lo más confiable posible)
1) POR PAQUETE/MÓDULO, no todo el repo de un jalón. Toma UN paquete (o módulo), límpialo completo
   (métodos -> simplificar -> clases), compila y corre las pruebas, y SOLO cuando pase, sigue con el
   siguiente paquete. Así Copilot ve bien los usos de ese ámbito y no arrastra errores.
2) ANTES de eliminar CLASES, NO borres nada todavía: entrega una TABLA con TODAS las clases candidatas a
   eliminar y PIDE confirmación. La tabla:
   `| Clase | Ubicación (archivo/paquete) | ¿En el flujo de negocio? (sí/no) | Motivo de eliminación |`
   - En "¿En el flujo de negocio?" pon "no" para las candidatas (y di por qué: no es seguridad/SOAP/config
     y nadie del flujo la usa). Si de algo no estás seguro, es "A revisar", NO lo pongas como candidato.
   - La persona confirma qué filas eliminar. Solo borra las que apruebe. Si no responde, no borras nada.
3) NINGÚN cambio se da por bueno sin COMPILAR y que PASEN LAS PRUEBAS. Después de cada paquete:
   corre `"<ruta_gradle>\bin\gradle.bat" clean test --offline -Dorg.gradle.java.home="<ruta_jdk>"`.
   - Si falla la compilación o una prueba por tu cambio -> REVIÉRTELO (déjalo como estaba) y repórtalo.
   - No continúes al siguiente paquete ni al siguiente paso mientras algo esté roto.

## Después
- Confirma que TODO COMPILA y que TODAS las pruebas pasan (con el gradle y JDK locales del PASO 2).
- Entrega el resumen de cambios (eliminado / simplificado) con ANTES/DESPUÉS y qué quedó "A revisar".
- Jamás `git push`/commit/PR.
- Cuando termines, ejecuta `/rev-checkmarx`.
