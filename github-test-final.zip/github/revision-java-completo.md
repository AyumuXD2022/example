# INSTRUCCIONES COMPLETAS — Pipeline Java/Spring Boot (todo en uno)

Pega este archivo COMPLETO en Copilot Chat con #file: y pídele que lo aplique.
Flujo: contexto decide -> Spring: 6 pasos | Java normal: solo limpieza + checkmarx.

============================================================
## BASE (aplica siempre) + PASO 2 (entorno)
============================================================

## Rol
Actúa como DESARROLLADOR SENIOR Java / Spring Boot. Respondes en español, te basas en el código
REAL del proyecto. No inventes. Si algo no está claro, márcalo "A revisar" y explica por qué.

## Reglas globales (OBLIGATORIAS en todos los pasos)
- ANTES de agregar CUALQUIER código o dependencia, LEE el `build.gradle` (y el BOM/versiones)
  para saber qué tiene REALMENTE el proyecto. NO agregues código que dependa de una librería que
  el proyecto NO tiene. Si de verdad hace falta una dependencia nueva, NO la metas en silencio:
  dilo, di cuál y por qué, y deja que la persona decida.
- Esto aplica también a una SOLA clase (`#file:`): si no tienes el `build.gradle` en contexto,
  PÍDELO antes de proponer código.
- Si hay varios módulos / varios `build.gradle`, PREGUNTA dónde están (la ruta) antes de empezar.
- NO rompas la funcionalidad: cambios mínimos y del estilo del proyecto. Todo con ANTES/DESPUÉS.
- NUNCA ejecutes `git add`, `git commit`, `git push` ni abras Pull Request, en NINGÚN paso.
  Solo propones/aplicas cambios en el editor; el commit y el PR los hace la persona.

## Entorno (PASO 2 — nunca descargar Gradle ni el JDK)
- NUNCA descargues Gradle ni el JDK. El proyecto ya tiene su versión y la persona la tiene local.
- GRADLE: PRIMERO lee la versión que usa el proyecto en `gradle/wrapper/gradle-wrapper.properties`
  (campo `distributionUrl`) y DÍSELA a la persona (ej. "el proyecto usa Gradle 8.14.3").
  DESPUÉS pídele SOLO la RUTA/carpeta de ESA versión (ej. `C:\gradle\gradle-8.14.3`). TÚ completas
  el resto: el ejecutable (`\bin\gradle.bat` en Windows, `/bin/gradle` en Linux/Mac) y el comando
  con `--offline`. No le pidas el comando entero, solo la carpeta. No uses `./gradlew` (eso baja la
  distribución); usa el gradle local de esa ruta.
- JDK: PRIMERO lee la versión de Java del `build.gradle` (`java { toolchain { languageVersion } }`
  o `sourceCompatibility`) y DÍSELA a la persona (ej. "el proyecto usa Java 21"). DESPUÉS pídele
  SOLO la RUTA/carpeta de ESE JDK (ej. `C:\Java\jdk-21`). NO uses la variable `JAVA_HOME` (puede
  apuntar a otro JDK): corre Gradle con `-Dorg.gradle.java.home="<ruta_del_jdk>"`. TÚ armas el comando.
- Si la persona tiene varias versiones instaladas, que te pase la carpeta de la que COINCIDE con la
  del proyecto. Si algo falta, DILO en vez de descargarlo.
- Ejemplo de comando final que tú armas (no se lo pidas a la persona):
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"

============================================================
## /contexto
============================================================


# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y empápate de cómo funciona. NO cambies nada
en este paso: solo entender y documentar. Trabaja con el código REAL, no inventes.

NOTA: `@workspace` no siempre mete el repo entero al contexto. Si el proyecto es grande, ve por
paquetes/carpetas y DILO ("revisé estos paquetes"). No afirmes algo de código que no viste.

## COBERTURA DE LECTURA (dilo explícito, importante)
- ENUMERA todos los paquetes/módulos de nivel alto del proyecto (lo que veas en `src/main/java`).
- Marca cuáles REVISASTE a fondo y cuáles NO alcanzaste a leer (por tamaño o porque `@workspace` no los
  trajo). Entrega una lista clara: "Leídos: [...] / NO leídos (incompletos): [...]".
- Si hay paquetes NO leídos, AVISA que el mapa de flujo puede estar INCOMPLETO en esas zonas, y
  recomienda revisarlos por módulo (o que la persona te los pase con `#file:`/por paquete) antes de
  que `/limpieza` borre nada que dependa de ellos. Lo de paquetes no leídos va "A revisar", nunca "no".

## ANTES DE TERMINAR — pregunta obligatoria si quedó algo sin leer
- Si hay CLASES que NO leíste o que leíste a MEDIAS (incompletas), NO cierres el contexto todavía.
  LISTA esas clases por nombre (clase + archivo/paquete) y marca cuáles están "sin leer" y cuáles
  "incompletas".
- Luego PREGÚNTALE a la persona, para CADA una (o en bloque): "¿Quieres que lea COMPLETAS estas clases
  (me enfoco en ellas e ignoro el resto por ahora), o sigo con lo ya leído aunque queden incompletas?"
- Si dice que SÍ: pídele que te las pase con `#file:` (o ábrelas) y LÉELAS COMPLETAS en ese momento;
  enfócate solo en esas e ignora lo demás. Luego completa el mapa con lo que leíste.
- Si dice que NO (o no responde): deja esas clases como "A revisar / incompleta" en el mapa y dilo
  claramente, para que `/limpieza` no borre nada que dependa de ellas.

## Primero: ¿cómo se construye el proyecto?
- Busca el `build.gradle` (y `settings.gradle` / `gradle/wrapper/`).
- Si NO encuentras `build.gradle` en ninguna parte, NO asumas Gradle. PREGUNTA a la persona:
  "No veo un `build.gradle`. ¿Es un Java Project de Eclipse (sin Gradle)?"
  Y mientras tanto detecta qué tipo de proyecto es, por sus archivos:
    * Eclipse Java Project clásico -> tiene `.project` y `.classpath` (y carpeta `bin/`), compila con Eclipse.
    * Maven  -> tiene `pom.xml`.
    * Ant    -> tiene `build.xml`.
- DILE qué detectaste y espera confirmación. Si es Eclipse/Maven/Ant (no Gradle), AVISA que los pasos
  que usan Gradle (entorno, compilar, `jacocoTestReport`) se harán con la herramienta real de ESE
  proyecto, y pide cómo compila/prueba la persona antes de seguir. No inventes comandos de Gradle.

### Si es un Java Project (Eclipse, sin gestor de dependencias)
- No hay `build.gradle`/`pom.xml` que liste las dependencias. Para revisar el código y lo COMPILADO,
  PIDE a la persona la RUTA de la carpeta donde están CONCENTRADAS todas las librerías (los `.jar`),
  normalmente `lib/` o la que use el `.classpath`. Esa carpeta de jars hace de "dependencias": úsala
  para saber qué librerías/APIs existen (NO asumas ninguna que no esté ahí).
- PREGUNTA qué **versión de Java (JDK)** usa el proyecto y pídele la RUTA de ese JDK. A partir de ahí,
  TODOS los pasos (sobre todo `/limpieza`) deben APEGARSE a ESA versión de Java: no introduzcas
  sintaxis ni APIs de una versión más nueva (ej. si es JDK 8, nada de `var`, `records`, `switch`
  expression, `List.of`, text blocks, etc.; si es JDK 11, nada de lo que llegó después). El código debe
  seguir compilando con la versión que te diga, no con otra.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> procesamiento -> salida.
2. **Componentes**: controllers, services, repositorios, clientes, config, utilidades.
3. **¿Accede a BASE DE DATOS?** Sí/No. Si sí: motor (Oracle, SQL Server, etc.), cómo se conecta
   (JPA/Hibernate, JdbcTemplate, Connection directa), entidades/queries principales.
4. **¿Es o consume SOAP?** Sí/No. Si sí:
   - Endpoint(s) / WSDL que usa.
   - **Con qué herramienta se generaron las clases del SOAP** (wsimport de JAX-WS, CXF `wsdl2java`,
     Apache Axis, JAXB `xjc`, el plugin de Gradle que sea). Mira el `build.gradle` (tasks/plugins
     como `wsimport`, `wsdl2java`, `jaxws`, `jaxb`, `xjc`) y los paquetes generados.
   - En qué PAQUETE quedan las clases generadas (ej. `com.bns.xsd.*`).
5. **¿Consume OTRO servicio (REST/HTTP u otro)?** Sí/No. Si sí: cuál, con qué cliente
   (RestTemplate, WebClient, Feign, OkHttp) y a qué URL/base.
6. **Generadores de clases a partir de XML/WSDL/XSD**: LISTA TODAS las herramientas que encuentres
   que generen clases (wsimport, xjc, wsdl2java, Axis, plugins de Gradle), con el task del
   `build.gradle` y el paquete de salida de cada una. Ponlas TODAS, no solo una.
7. **Configuración relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.
8. **CONFIGURACIÓN DE SEGURIDAD:** ¿hay config de seguridad? (Spring Security: `SecurityFilterChain`,
   `WebSecurityConfigurerAdapter`, filtros, JWT; o WS-Security/credenciales en el cliente SOAP). Di qué
   clases la forman. ESTAS CLASES FORMAN PARTE DEL FLUJO (aunque no se vean "llamadas" directo): NO son
   código muerto. Márcalas "en el flujo".
9. **CONFIGURACIÓN DE SOAP y CÓDIGO GENERADO:** ¿hay config de SOAP? (endpoint/cliente, CXF/JAX-WS beans,
   `@Configuration` del WS, WSDL). Di qué clases la forman -> forman parte del flujo.
   Y MUY IMPORTANTE: identifica el PAQUETE de las clases GENERADAS por SOAP (wsimport/xjc/wsdl2java).
   En un proyecto con SOAP (sobre todo Java Project) NO todas las clases generadas se usan, y eso es
   NORMAL: ese código NO se elimina. Marca TODO el paquete generado como "GENERADO — NO ELIMINAR" en el
   mapa, aunque algunas clases parezcan sin uso.
10. **LÓGICA DE NEGOCIO Y FLUJO (importante para la limpieza):**
   - Traza el/los FLUJO(S) principal(es): desde el punto de entrada (controller/endpoint/listener/`main`)
     hasta la salida (BD, otro servicio, respuesta), pasando por services, puertos/clientes y utilidades.
   - Di dónde está la LÓGICA DE NEGOCIO real (reglas, cálculos, validaciones) y en qué clases/métodos.
   - CLASIFICA cada clase: ¿está EN el flujo (se alcanza desde un punto de entrada y participa en el
     negocio) o NO está en el flujo (no la alcanza nadie del flujo real)? Recuerda que algo puede estar
     "vivo" por Spring/reflexión/JPA/serialización/endpoints aunque no se vea llamado directo, y que la
     config de SEGURIDAD y de SOAP, y TODO el código GENERADO por SOAP, cuentan como "en el flujo / no eliminar".

## Entrega
- Un resumen claro en español con los puntos de arriba.
- Una tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`
- Un MAPA DE FLUJO / clases: `| Clase | ¿En el flujo? (sí/no/A revisar/GENERADO) | Rol en el negocio | Quién la usa |`.
  Este mapa es la BASE de `/limpieza` (qué métodos/clases quitar). Si no pudiste confirmar que algo NO
  se usa (p.ej. no viste todo el repo), ponlo "A revisar", no "no". Las clases GENERADAS por SOAP y las
  de config de SEGURIDAD/SOAP márcalas "GENERADO" o "en el flujo" = NO se eliminan.
- Un DIAGRAMA DEL FLUJO en **Mermaid** (`flowchart`): desde el punto de entrada hasta la salida, con las
  clases/componentes reales por los que pasa (controller -> service -> repositorio/cliente -> BD/SOAP/REST).
  Usa los NOMBRES reales de las clases que leíste; no inventes. Ejemplo de forma:

  ```mermaid
  flowchart LR
    IN[XxxController] --> SVC[XxxService]
    SVC --> REPO[XxxRepository]
    REPO --> DB[(Base de datos)]
    SVC --> SOAP[XxxSoapClient] --> EXT[Servicio SOAP externo]
  ```
- Marca con "A revisar" lo que no pudiste confirmar.

## ¿Es Spring o Java normal? (decide qué pasos siguen)
Determina si el proyecto usa **Spring / Spring Boot**: búscalo en el `build.gradle`/`pom.xml`
(dependencias `org.springframework...`, `spring-boot-starter-*`) y en el código
(`@SpringBootApplication`, `@RestController`, `@Service`, `@Autowired`). DILO claramente.
- Si ES Spring: continúa con el flujo COMPLETO (entorno -> `/limpieza` -> `/checkmarx` -> `/snyk` -> `/test`).
- Si es un Java Project NORMAL (SIN Spring): el flujo es CORTO. Solo harás `/limpieza` y luego
  `/checkmarx`. En `/checkmarx`: si hay informe, lo mitigas; si NO hay informe, TERMINAS ahí.
  NO hagas `/snyk` ni `/test`. Avísale esto a la persona.

RECUERDA (reglas base): jamás `git push`/commit/PR, y en los siguientes pasos no agregues código de
dependencias que no estén en el `build.gradle`.

Cuando termines, si ES Spring ejecuta el **PASO 2 (entorno)**: dime qué versión de Gradle y de Java
usa el proyecto y pídeme SOLO las rutas locales; luego sigue con `/limpieza`. Si es Java normal,
pasa directo a `/limpieza` (y después `/checkmarx`).

============================================================
## /limpieza
============================================================


# PASO 3 — Limpieza: eliminar código muerto y simplificar

ANTES DE EMPEZAR, según el tipo de proyecto (visto en `/contexto`):
- Si NO es un Java Project (es Gradle/Maven): PRIMERO LEE el `build.gradle`/`pom.xml` (y el BOM) para
  saber qué dependencias tiene REALMENTE y qué versión de Java usa.
- Si ES un Java Project de Eclipse: usa la carpeta de `.jar` que te dieron como lista de dependencias
  y la versión de Java (JDK) que te indicaron.
En ambos casos: al simplificar NO uses APIs/clases de una librería que el proyecto NO tiene; básate
SOLO en las dependencias presentes (y en el JDK del proyecto). No metas imports ni utilidades de una
librería ausente (ej. Guava/Apache Commons/Lombok si no están). Si una simplificación necesitaría algo
que no está, NO la hagas (o dilo y deja que la persona decida).

LEE LA VERSIÓN DE JAVA y APÉGATE a ella:
- Si es proyecto GRADLE: léela en el `build.gradle` (`java { toolchain { languageVersion } }` o
  `sourceCompatibility`/`targetCompatibility`) y usa ESE nivel de JDK.
- Si es un Java Project de Eclipse: usa la versión de JDK que te indicó la persona (y la carpeta de `.jar`).
NO introduzcas sintaxis ni APIs de una versión MÁS NUEVA que esa: si es JDK 8, nada de `var`, `records`,
`switch` expression, `List.of`, text blocks, etc.; si es JDK 11, nada posterior a 11. El código debe
seguir compilando con ESA versión. Si no sabes la versión, PREGÚNTALA antes de simplificar.

Aquí haces dos cosas, SIEMPRE con el MISMO comportamiento (nada cambia de funcionalidad) y con
ANTES/DESPUÉS:
1) ELIMINAR lo que no se usa (clases y métodos muertos).
2) SIMPLIFICAR el código que sí se usa: dejarlo MÁS SIMPLE y legible pero con EXACTAMENTE la misma
   funcionalidad (mismo resultado y mismo comportamiento observable). Si no queda equivalente, no lo toques.

ANTES de simplificar un método, LEE y ENTIENDE qué hace (su funcionalidad). Solo simplifícalo si
queda más simple y legible SIN cambiar lo que hace. Si un método NO se puede simplificar sin arriesgar
su comportamiento, NO pasa nada: déjalo tal cual. Nunca fuerces una simplificación; siempre el camino
seguro que NO afecte la funcionalidad.

## Alcance (solo lo que ves)
- Analiza SOLO el código que tienes en contexto (archivos `#file:` o lo que trajo `@workspace`).
- Para afirmar que algo NO se usa, tienes que PODER ver dónde se usaría. Si no tienes esa
  visibilidad, NO borres: dilo y pide los archivos que faltan (o que agreguen `@workspace`).
- NO toques el código generado (wsimport/xjc/wsdl2java) detectado en `/contexto`.

## Qué eliminar (si confirmas que no se usa)
- Clases que no se referencian en ningún lado.
- Métodos privados que nadie llama.
- Variables, campos y parámetros sin usar; imports sin usar.
- `import` con comodín (`import java.util.*;`) -> imports EXPLÍCITOS de lo que se usa.
- Código comentado que ya no sirve.

## Simplificar (sin cambiar el comportamiento)
Solo cambios SEGUROS y equivalentes, que no alteran lo que hace el código. Ejemplos permitidos:
- Booleanos redundantes: `if (x == true)` -> `if (x)`; `if (c) return true; else return false;` -> `return c;`.
- `else` innecesario después de un `return`/`throw`.
- `if` anidados que se pueden unir con `&&` cuando el resultado es idéntico.
- Variables locales usadas una sola vez que solo repiten un valor (inline), si queda más claro.
- Operador diamante `new ArrayList<>()`, quitar casts redundantes, imports/`this.` innecesarios.
- `try-with-resources` en lugar de cerrar manualmente en `finally` (mismo cierre, menos código).
- Condiciones u ramas IMPOSIBLES/duplicadas que nunca cambian el resultado.
- Unir código DUPLICADO en un método privado, SOLO si el comportamiento queda idéntico.
Reglas de la simplificación:
- Si existe CUALQUIER duda de que cambie el comportamiento (orden de efectos, null, excepciones,
  tipos, concurrencia), NO lo toques: márcalo "A revisar".
- No renombres API pública ni cambies firmas de métodos. No cambies el estilo por gusto.
- Nada de "optimizaciones" que cambien resultados o rendimiento observable.

## Orden de trabajo (hazlo en este orden)
0) APÓYATE EN EL MAPA DE FLUJO / LÓGICA DE NEGOCIO que hizo `/contexto` (qué clases están EN el flujo y
   cuáles NO, y dónde está la lógica real). Ese mapa decide qué se puede quitar. Y ya tienes del inicio
   las dependencias y la versión de Java a la que apegarte.

1) MÉTODOS MUERTOS primero: mirando el flujo/lógica de negocio, elimina los MÉTODOS que no participan en
   el negocio y que nadie del flujo llama. Igual variables/parámetros/imports sin usar, `import *` ->
   explícitos, y código comentado muerto. (Cascada: ver abajo.) No toques el código generado (SOAP).

2) SIMPLIFICA el código que SÍ se usa (el del flujo/negocio): déjalo más simple y legible pero con
   EXACTAMENTE la misma funcionalidad. ANTES de simplificar un método, entiende qué hace. Si un trozo
   NO se puede simplificar sin arriesgar el comportamiento, NO pasa nada: déjalo igual.

3) AL FINAL, ELIMINA LAS CLASES que NO están en el flujo ni en la lógica de negocio (las que el mapa de
   `/contexto` marcó "no"). Aplica la cascada. Para DTO/Entity (y model/vo/pojo):
   - clase DTO/Entity que NO está en el flujo -> elimínala.
   - clase DTO/Entity que SÍ está en el flujo -> DÉJALA TAL CUAL, NO le quites atributos aunque parezcan
     sin usar (un campo suele mapear BD/JSON o usarse por reflexión).
   - Si una clase está marcada "A revisar" en el mapa (no se pudo confirmar que no se usa), NO la borres.
   - NUNCA elimines el código GENERADO por SOAP (wsimport/xjc/wsdl2java), AUNQUE algunas clases generadas
     no se usen: en un proyecto con SOAP eso es NORMAL y ese paquete no se toca. Tampoco elimines las
     clases de CONFIGURACIÓN de SEGURIDAD ni de SOAP (están "en el flujo" aunque no se vean llamadas).

## Imports explícitos (no nombres cualificados en el cuerpo)
- Si en el código hay un tipo escrito con su paquete completo, p. ej.
  `private com.mx.entity.Clase clase;` o `com.mx.entity.Clase x = new com.mx.entity.Clase();`,
  cámbialo por un IMPORT explícito arriba y el nombre SIMPLE en el cuerpo:
      import com.mx.entity.Clase;
      ...
      private Clase clase;
- CHOQUE DE NOMBRES: si en ese MISMO archivo se usan DOS clases distintas con el MISMO nombre simple
  (ej. `com.mx.entity.Clase` y `com.otro.Clase`), no se pueden importar las dos. Entonces RENOMBRA una
  de las clases a un nombre claro y distinto, pon los imports explícitos de ambas y actualiza TODOS los
  usos. DOCUMENTA el cambio: nombre ANTES -> DESPUÉS, el archivo de la clase y en qué archivos se usaba.
  Luego VERIFICA que compile.
  Seguridad al renombrar: NO renombres el código GENERADO (SOAP/wsimport/xjc) ni una clase que sea API
  pública consumida FUERA de este proyecto; en esos casos renombra la OTRA. Si ninguna se puede
  renombrar sin riesgo, déjalo con el paquete completo y dilo.
- El cambio de import es cosmético; el renombrado ajusta nombre y usos pero NO cambia la funcionalidad.

## Código muerto EN CASCADA (importante)
- Una referencia que viene de código MUERTO no cuenta como "uso". Si la clase `A` usa a la clase `B`,
  pero `A` NO se usa en ningún lado (está muerta), entonces `B` queda sin uso real: elimina las DOS.
- Trabaja en CASCADA: después de borrar una clase/método muerto, VUELVE a revisar lo que esa clase/
  método usaba; si quedó sin uso real (solo lo llamaba lo que acabas de borrar), bórralo también.
  Repite hasta que no quede nada que solo dependiera de código ya eliminado.
- Esto NO aplica a DTO/Entity que SÍ se usan (a esos no se les tocan atributos). Y mantén el candado:
  si algo puede estar vivo por Spring/reflexión/JPA/endpoints, no lo borres (márcalo "A revisar").

En cada punto: LISTA primero lo detectado (archivo:línea y por qué) y aplica con ANTES/DESPUÉS,
separando "eliminado" de "simplificado". El código debe hacer EXACTAMENTE lo mismo que antes.

## NO eliminar si hay duda
Puede estar vivo por vías que no se ven: inyección de Spring (`@Component/@Service/@Bean/@Autowired`),
reflexión, serialización (Jackson/JAXB), entidades/campos JPA, métodos públicos usados desde otro
módulo, endpoints, `main`, jobs. Ante CUALQUIER duda, NO borres: márcalo "A revisar".

## Cómo trabajar (OBLIGATORIO — para que sea lo más confiable posible)
1) POR PAQUETE/MÓDULO, no todo el repo de un jalón. Toma UN paquete (o módulo), límpialo completo
   (métodos -> simplificar -> clases), compila y corre las pruebas, y SOLO cuando pase, sigue con el
   siguiente paquete. Así Copilot ve bien los usos de ese ámbito y no arrastra errores.
2) ANTES de eliminar CLASES, NO borres nada todavía: entrega una TABLA con TODAS las clases candidatas a
   eliminar y PIDE confirmación. La tabla:
   `| Clase | Ubicación (archivo/paquete) | ¿En el flujo de negocio? (sí/no) | Motivo de eliminación |`
   - En "¿En el flujo de negocio?" pon "no" para las candidatas (y di por qué: no es seguridad/SOAP/config
     y nadie del flujo la usa). Si de algo no estás seguro, es "A revisar", NO lo pongas como candidato.
   - La persona confirma qué filas eliminar. Solo borra las que apruebe. Si no responde, no borras nada.
3) NINGÚN cambio se da por bueno sin COMPILAR y que PASEN LAS PRUEBAS. Después de cada paquete:
   corre `"<ruta_gradle>\bin\gradle.bat" clean test --offline -Dorg.gradle.java.home="<ruta_jdk>"`.
   - Si falla la compilación o una prueba por tu cambio -> REVIÉRTELO (déjalo como estaba) y repórtalo.
   - No continúes al siguiente paquete ni al siguiente paso mientras algo esté roto.

## Después
- Confirma que TODO COMPILA y que TODAS las pruebas pasan (con el gradle y JDK locales del PASO 2).
- Entrega el resumen de cambios (eliminado / simplificado) con ANTES/DESPUÉS y qué quedó "A revisar".
- Jamás `git push`/commit/PR.
- Cuando termines, ejecuta `/checkmarx`.

============================================================
## /checkmarx
============================================================


# PASO 4 — Checkmarx (mitigar hallazgos)

PRIMERO PREGUNTA: "¿Tienes un informe de Checkmarx?"

- Si la persona dice **NO**: no hagas nada aquí, pasa directo a `/snyk`.
- Si dice **SÍ**: pídele que te PASE el informe (o el hallazgo) y que te diga **EN QUÉ CLASE/archivo**
  está cada hallazgo. No adivines; trabaja solo sobre lo que te pase.

## Antes de corregir
- LEE el `build.gradle` (regla base). NO agregues código que dependa de una librería que el proyecto
  NO tiene. Si una corrección necesitara una dependencia nueva, DILO y deja que la persona decida;
  prioriza arreglarlo con lo que ya está en el proyecto.

## Cómo mitigar cada hallazgo
1) Ubica la clase/línea exacta del informe.
2) Explica brevemente qué es el hallazgo (query de Checkmarx / CWE si viene en el informe) y por qué
   aplica aquí.
3) Da el código VULNERABLE (antes) y el CORREGIDO (después): mínimo, idiomático y con librerías ya
   presentes. Explica por qué cierra el flujo que marca Checkmarx (fuente -> sink).
4) Si crees que es FALSO POSITIVO, dilo y justifícalo (para marcarlo "Not Exploitable").
5) NO rompas la funcionalidad. Si un arreglo necesita decisión de negocio, plantéala y recomienda.

## Entrega
- Lista de hallazgos del informe con su estado: corregido / falso positivo / A revisar.
- El antes/después de cada clase tocada.
- Jamás `git push`/commit/PR.

Al terminar, depende del tipo de proyecto (visto en `/contexto`):
- Si es Spring: ejecuta `/snyk`.
- Si es Java normal (sin Spring): aquí TERMINA el flujo. No ejecutes `/snyk` ni `/test`.
  (Y si en este proyecto Java normal no había informe de Checkmarx, el flujo ya terminó en `/limpieza`.)

============================================================
## /snyk
============================================================


# PASO 5 — Snyk (dependencias vulnerables)

PRIMERO PREGUNTA: "¿Tienes un informe de vulnerabilidades de dependencias de Snyk?"

- Si la persona dice **NO**: no hagas nada aquí, pasa directo a `/test`.
- Si dice **SÍ**: pídele el informe y LÉELO completo. Para CADA vulnerabilidad fíjate en si tiene
  arreglo: Snyk lo indica como "fixed in <versión>" / "upgradable" / "patchable" (hay versión que
  la corrige) o como "No fix available / no hay upgrade" (sin arreglo).

## Caso A — La vulnerabilidad ES fixable (dice "fixed in <versión>")
1) LEE TODO el `build.gradle` (y el BOM) para ubicar la dependencia y su versión actual, y ver si la
   versión la fija un BOM (en ese caso puede no llevar número).
2) Confirma que la versión de arreglo EXISTE para ese `groupId:artifactId` (Maven Central /
   mvnrepository.com). Si NO tienes acceso a internet para verificarlo, NO inventes: usa la versión
   EXACTA que dice el informe de Snyk ("fixed in ...") y pide a la persona que la confirme.
3) ACTUALIZA la versión en el `build.gradle` (ANTES/DESPUÉS), respetando cómo maneja versiones el
   proyecto (número directo vs BOM/propiedad de versión).
4) Recompila con el gradle y JDK locales (PASO 2):
   `"<ruta_gradle>\bin\gradle.bat" clean build --offline -Dorg.gradle.java.home="<ruta_jdk>"`
5) Si la nueva versión CAMBIÓ algo (API renombrada/eliminada, paquetes movidos): estúdialo y AJUSTA
   el código afectado para que TODO funcione IGUAL que antes. Explica cada ajuste con ANTES/DESPUÉS.

## Caso B — La vulnerabilidad NO tiene arreglo (no fix / no upgrade disponible)
- NO inventes una versión ni "subas por subir". Si no hay versión que la arregle, NO toques el
  `build.gradle`.
- Dile a la persona que esa vulnerabilidad hay que GESTIONARLA (ignorar con justificación) en el
  archivo de política de Snyk: **`.snyk`** (en la raíz del proyecto).
- AYÚDALE a escribir la entrada en `.snyk` con su justificación. Formato:

    version: v1.5.0
    ignore:
      SNYK-JAVA-GRUPO-ID-0000000:        # <-- el ID exacto de la vuln en el informe de Snyk
        - '*':
            reason: >-
              <justificación real: por qué se acepta — no hay fix disponible, no es explotable en
              nuestro contexto, o es dependencia transitiva sin versión segura, etc.>
            expires: 2026-12-31T00:00:00.000Z   # <-- fecha de caducidad de la excusa (revísala luego)

- DÉJALE claro: hay que poner el **ID de la vulnerabilidad tal cual** del informe, una **razón real**
  (no genérica) y una **fecha de expiración** para volver a revisarla. La decisión de ignorar es de
  la persona/equipo; tú solo preparas la entrada.

## Entrega
- Tabla: `| Dependencia | ID Snyk | ¿Fixable? | Versión antes | Versión después | ¿Rompe? | Ajustes / Acción |`
  (en "Acción" pon: actualizada, o "ignorada en .snyk con justificación").
- ANTES/DESPUÉS del `build.gradle` (Caso A) o la entrada del `.snyk` (Caso B).
- Jamás `git push`/commit/PR.

Cuando termines (o si no había informe), ejecuta `/test`.

============================================================
## /test
============================================================


# PASO 6 — Pruebas, cobertura y exclusiones

## REGLA DE ORO: NO modifiques el código de producción
- Este paso SOLO agrega/edita CÓDIGO DE PRUEBA (`src/test/...`), dependencias de TEST y las exclusiones
  de cobertura. NUNCA cambies el código de negocio/producción para que una prueba pase.
- Las pruebas se SACAN DE CÓMO FUNCIONA EL CÓDIGO HOY (su comportamiento REAL actual), no de cómo
  "debería" funcionar. Lee el método, entiende qué hace, y haz aserciones sobre ESE resultado real.
- Si al probar descubres algo que PARECE un bug (el método no hace lo "esperado"): NO cambies el código.
  Repórtalo como "A revisar / posible bug" y deja que la persona decida. La prueba refleja el estado actual.

## 1) Releer el código
- Si se pasó por `/checkmarx` (PASO 4) y/o `/snyk` (PASO 5): vuelve a LEER las clases tocadas para
  ver qué cambió y confirmar que siguen funcionando igual.
- Si NO hubo esos informes: LEE todo el código (por paquetes si es grande) para partir del estado real.

## 2) Exclusiones en sonar-project.properties (NO lo crees — YA existe)
- El proyecto YA tiene su `sonar-project.properties`. NUNCA lo crees ni lo reestructures.
- Solo ÁBRELO y mira `sonar.exclusions` y `sonar.coverage.exclusions`.
- Al momento de testear, AGREGA a esas dos propiedades la CLASE GENERADA por el SOAP (el código
  de wsimport/xjc/wsdl2java que detectaste en `/contexto`) para EXCLUIRLA del análisis y de la
  cobertura. Respeta el MISMO formato de rutas que ya use el archivo; no borres lo que ya esté.
- CONFIGURACIÓN: PRIMERO intenta PROBAR lo que tenga algo de lógica (una `@Configuration` que arma un
  bean con lógica, un converter, un validator, etc.) — probar es mejor que excluir. SOLO si de verdad
  NO hay nada que testear (puro cableado, constantes, enums, `@SpringBootApplication` main), exclúyelo
  de la COBERTURA (`sonar.coverage.exclusions`, no de `sonar.exclusions`) para que no aparezca en 0%.
  La decisión FINAL de qué excluir se toma en el paso 6 MIRANDO el reporte (las clases en 0%).
  NO excluyas código de NEGOCIO (servicios, lógica, mappers con reglas): eso se prueba.

## 3) Dependencias de prueba (agrega SOLO las de test que falten)
- PRIMERO LEE el `build.gradle` para ver qué dependencias ya existen (no dupliques) y en qué scope.
- Si faltan dependencias para poder probar, AGRÉGALAS pero SOLO de ámbito de PRUEBA
  (`testImplementation` / `testRuntimeOnly` / `testCompileOnly` / `testAnnotationProcessor`).
  NUNCA agregues ni cambies dependencias de producción (`implementation`/`api`/`compileOnly`):
  este paso solo toca lo de TEST. Reporta cuáles agregaste y por qué.
- Usa los nombres de artefacto CORRECTOS. OJO con estos errores comunes:
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc'  -> MVC va en 'spring-boot-starter-web'
    * NO existe 'org.springframework.boot:spring-boot-starter-security-test'
         -> es 'org.springframework.security:spring-security-test'
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc-test'
         -> @WebMvcTest/MockMvc ya vienen en 'spring-boot-starter-test'
- Base de pruebas (casi siempre):
    testImplementation 'org.springframework.boot:spring-boot-starter-test'   // JUnit5 + Mockito + AssertJ + MockMvc
    testRuntimeOnly   'org.junit.platform:junit-platform-launcher'
- Según lo que use el módulo (agrega solo lo que aplique):
    Spring Security -> testImplementation 'org.springframework.security:spring-security-test'
    Lombok en tests -> testCompileOnly 'org.projectlombok:lombok'
                       testAnnotationProcessor 'org.projectlombok:lombok'
    WebFlux/Reactor -> testImplementation 'io.projectreactor:reactor-test'
    Cliente REST    -> testImplementation 'com.squareup.okhttp3:mockwebserver'  (o WireMock)
    JPA / BD        -> 'com.h2database:h2' o Testcontainers
- Deja la versión al BOM de Spring Boot cuando aplique (sin número). Si ya están, no las dupliques.

## 4) Generar las pruebas (meta: >= 85%, ideal 100%)
- JUnit 5 + Mockito. Slice correcto: `@ExtendWith(MockitoExtension.class)` (servicios),
  `@WebMvcTest` (controllers), `@DataJpaTest`/repos mockeados (datos). Patrón AAA, nombres claros.
- Mockea TODA dependencia externa (BD/Connection, clientes SOAP/REST, colas, config). Aserciones reales.
- Cubre lo NO excluido: métodos públicos (camino feliz + error), ramas (if/else, switch, catch, null).

## 5) Correr pruebas + JaCoCo y LEER los resultados
- Corre con el gradle y JDK locales (PASO 2):
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"
- Cuando TODAS pasen, LEE el reporte de JaCoCo (`build/reports/jacoco/test/html/index.html` o el
  `jacocoTestReport.xml`). Si no lo encuentras, PIDE la RUTA y léelo en ese momento (ej.
  `/pega-baas-debit-card-transactions/build/reports/jacoco/test/html/index.html`).

## 6) Mirar las clases en 0%, clasificarlas y excluir solo lo que corresponde (y re-verificar)
- En el reporte, LOCALIZA las clases que quedaron en 0% (o muy bajas). Para CADA una, decide:
  * ¿Es código GENERADO por el SOAP? -> exclúyela.
  * ¿Es pura CONFIGURACIÓN / sin lógica que probar (config, `@SpringBootApplication` main, constantes,
    enums, pojo/dto sin lógica)? -> exclúyela.
  * ¿Tiene lógica de NEGOCIO? -> NO la excluyas: AGRÉGALE pruebas para subir su cobertura.
- Lo que toque excluir, agrégalo al `exclude` del bloque `jacocoTestReport` del `build.gradle` (MISMO
  formato de ruta; deriva el paquete real del `build.gradle`/`contexto`, no copies ejemplos de otro repo)
  y a `sonar.coverage.exclusions`. Así esas clases ya NO salen en 0% ni bajan el %.
- Plantilla de referencia (ajusta los paquetes a ESTE proyecto):

    jacocoTestReport {
        dependsOn test
        reports {
            xml.required.set(true)
            csv.required.set(true)
            html.required.set(true)
        }
        afterEvaluate {
            classDirectories.setFrom(files(classDirectories.files.collect {
                fileTree(dir: it, exclude: [
                    // paquete GENERADO del SOAP/XSD de ESTE proyecto, ej.:
                    'com/bns/xsd/**',
                    'com/<paquete>/<generado>/**',
                    // clases SOLO de configuración / sin lógica que probar (ajusta a ESTE proyecto):
                    'com/<paquete>/config/**',
                    'com/<paquete>/constants/**',
                    'com/<paquete>/**/*Application.*'
                ])
            }))
        }
    }
    jacocoTestCoverageVerification {
        violationRules { rule { limit { minimum = 0.1 } } }
    }

- VUELVE a correr `test jacocoTestReport` y VERIFICA en el reporte que las clases que excluiste (SOAP y
  configuración) ya NO aparecen y que la cobertura refleja el cambio. Si alguna sigue apareciendo,
  revisa la ruta del `exclude` y repite hasta que quede bien excluida.
- NO excluyas tu código de negocio para "inflar" cobertura. Si una clase propia queda baja, AGREGA
  pruebas, no la excluyas.

## Entrega
- Qué se agregó a `sonar.exclusions` / `sonar.coverage.exclusions` y al `exclude` de `jacocoTestReport`.
- Dependencias de test agregadas (solo test) y por qué.
- Pruebas generadas (código completo) y cobertura final; qué falta para el 85% si no se llegó.
- Jamás `git push`/commit/PR.
