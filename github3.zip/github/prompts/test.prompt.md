---
mode: ask
description: "PASO 3 — Genera pruebas para cubrir >=85% de coverage (SonarQube/JaCoCo)"
---

# PASO 3 — Pruebas unitarias y coverage (>= 85%, ideal 100%)

ANTES DE GENERAR PRUEBAS: vuelve a LEER el código ACTUAL con @workspace / #codebase.
Ya pasó por `/limpieza`, así que cambió (se quitó código muerto, cambiaron imports).
Entiende cómo funciona AHORA cada clase y método que vas a probar — no asumas el estado previo.

Luego genera las pruebas necesarias para alcanzar al menos **85% de cobertura** (el mínimo
del Quality Gate de SonarQube). Si puedes llegar al **100%**, mejor. Sigue las reglas base del repo.

## Marco y estilo
- JUnit 5 (Jupiter) + Mockito. Para Spring, usa el slice correcto:
  `@ExtendWith(MockitoExtension.class)` para servicios, `@WebMvcTest` para controllers,
  `@DataJpaTest`/repos mockeados para acceso a datos.
- Patrón AAA (Arrange-Act-Assert). Nombre claro:
  `metodo_condicion_resultadoEsperado`.
- Las pruebas van en `src/test/java`, espejo del paquete de la clase bajo prueba.

## Dependencias de prueba (agrégalas a build.gradle si faltan)
- Detecta qué dependencias de PRODUCCIÓN requieren su contraparte de TEST y agrégala como
  `testImplementation` / `testRuntimeOnly`. Si ya están, no las dupliques. Deja la versión al
  BOM de Spring Boot cuando aplique (sin número). Reporta cuáles agregaste y por qué.
- Base (casi siempre):
    testImplementation 'org.springframework.boot:spring-boot-starter-test'   // JUnit5 + Mockito + AssertJ + Spring Test
    testRuntimeOnly 'org.junit.platform:junit-platform-launcher'
- Según lo que use el módulo:
    Spring Security      -> testImplementation 'org.springframework.security:spring-security-test'
    WebFlux / Reactor    -> testImplementation 'io.projectreactor:reactor-test'
    Cliente REST/HTTP    -> testImplementation 'com.squareup.okhttp3:mockwebserver'  (o WireMock) para simular el servicio
    Spring Kafka         -> testImplementation 'org.springframework.kafka:spring-kafka-test'
    JPA / BD             -> 'com.h2database:h2' o Testcontainers para pruebas de repositorio
- OJO: el artefacto de Spring Security para test es 'org.springframework.security:spring-security-test',
  NO 'spring-boot-starter-security-test' (ese no existe).

## Qué cubrir para llegar al 85%+ (ideal 100%)
- Todos los métodos públicos: camino feliz + caminos de ERROR/excepción.
- RAMAS: if/else, ternarios, switch, bloques catch, validaciones de null/vacío/límite.
  Para acercarte al 100%, cubre cada rama y cada excepción posible.
- Mockea TODA dependencia externa (no toques infra real): repositorios/DAO/Connection,
  clientes SOAP/REST (WebClient/RestTemplate/puertos JAX-WS), colas, config.
- Cada test con ASERCIONES reales. NO generes tests sin assert solo para "inflar" coverage.

## Cobertura (respeta las exclusiones del sonar-project.properties existente)
- El repo YA tiene `sonar-project.properties` con sus exclusiones (incluye el código generado
  por wsimport). LÉELO y respétalo: NO lo modifiques, NO agregues ni quites exclusiones.
- Genera pruebas SOLO para el código que CUENTA para la cobertura (lo NO excluido). No gastes
  pruebas en lo que `sonar.exclusions` / `sonar.coverage.exclusions` ya excluye (ej. el generado).
- Dentro de lo no excluido, cubre caminos felices y de ERROR, con aserciones reales:
  servicios (lógica de negocio) primero, luego el resto (model/dto/config propios) hasta
  superar el 85% (ideal 100%).
- Si una clase propia (no excluida) es imposible de cubrir con sentido, repórtalo con el motivo.

## SonarQube
- El repo YA tiene `sonar-project.properties` configurado. NO lo generes, NO lo modifiques:
  solo léelo para saber qué está EXCLUIDO (incluido el código generado por wsimport/xjc) y
  así NO gastar pruebas ahí. Todo lo NO excluido, cúbrelo hasta el 85% (ideal 100%).

## Verificar cobertura con JaCoCo y excluir el código generado
- DESPUÉS de correr los tests y confirmar que TODOS pasaron, LEE el reporte de JaCoCo para ver
  la cobertura REAL por clase. BÚSCALO primero en el proyecto (normalmente
  `build/reports/jacoco/test/html/index.html`, o el `jacocoTestReport.xml`). Si NO lo encuentras,
  PIDE a la persona la RUTA del reporte y léelo EN ESE MOMENTO (o que lo adjunte / pegue el resumen).
- Si hay código que NO debe contar (el GENERADO por wsimport/xjc, u otro que el proyecto ya
  excluye), agrégalo a la lista de exclusiones del bloque de build.gradle:
  `jacocoTestReport { afterEvaluate { classDirectories ... exclude: [ ... ] } }`, con el MISMO
  formato de path que ya usan (ej. `'com/bns/xsd/**'`, `'xsd/bns/**'`). No inventes el paquete:
  derívalo del build.gradle (task `wsimport` / `jaxwsSourceDir`) o pregunta la ruta.
- Luego VUELVE a correr los tests + `jacocoTestReport` y VERIFICA en el reporte que la exclusión
  se aplicó: esa clase generada ya NO aparece y la cobertura refleja el cambio.
- NO excluyas tu propio código de negocio para "inflar" la cobertura: solo lo generado (o lo que
  el proyecto ya tenía excluido). Si una clase propia queda baja, lo correcto es AGREGAR pruebas,
  no excluirla.

## Entrega
1) Lista de clases/métodos cubiertos y las pruebas generadas (código completo).
2) Qué dependencias de test faltan (ej. `spring-boot-starter-test`, `mockito-core`) si aplica.
3) Estimación: qué ramas/métodos quedan sin cubrir y qué prueba falta para superar el 85%.

No inventes comportamiento: si un método depende de algo que no está claro, márcalo "A revisar".
