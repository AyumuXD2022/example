package com.lacomer.lle.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Representacion de un recurso LLE.
 *
 * @author Orlando Ferreira Angon
 */
public record LleDto(
        Long id,
        @NotBlank String clave,
        @NotBlank String descripcion,
        @NotNull Integer cantidad) {
}
