package com.lacomer.lle.controller;

import com.lacomer.lle.config.SecurityConfig;
import com.lacomer.lle.exception.JsonAccessDeniedHandler;
import com.lacomer.lle.exception.JsonAuthenticationEntryPoint;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Valida que las reglas por scope funcionen extremo a extremo.
 *
 * Nota: el post-processor jwt() NO usa el JwtAuthenticationConverter de la
 * aplicacion. Aplica el suyo, que si agrega SCOPE_. Por eso las authorities se
 * declaran de forma explicita con .authorities(...).
 *
 * @author Orlando Ferreira Angon
 */
@WebMvcTest(LleController.class)
@Import({SecurityConfig.class, JsonAuthenticationEntryPoint.class, JsonAccessDeniedHandler.class})
class LleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private static final String BODY = """
            {"clave":"LLE-010","descripcion":"Alta desde test","cantidad":5}""";

    @Test
    void sinTokenDevuelve401() throws Exception {
        mockMvc.perform(get("/api/lle"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void conReadPuedeConsultar() throws Exception {
        mockMvc.perform(get("/api/lle")
                        .with(jwt().authorities(new SimpleGrantedAuthority("read.lle"))))
                .andExpect(status().isOk());
    }

    @Test
    void conReadNoPuedeEscribir() throws Exception {
        mockMvc.perform(post("/api/lle")
                        .with(jwt().authorities(new SimpleGrantedAuthority("read.lle")))
                        .contentType("application/json")
                        .content(BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    void conWritePuedeEscribir() throws Exception {
        mockMvc.perform(post("/api/lle")
                        .with(jwt().authorities(new SimpleGrantedAuthority("write.lle")))
                        .contentType("application/json")
                        .content(BODY))
                .andExpect(status().isOk());
    }

    @Test
    void authorityConPrefijoNoConcede() throws Exception {
        mockMvc.perform(get("/api/lle")
                        .with(jwt().authorities(new SimpleGrantedAuthority("SCOPE_read.lle"))))
                .andExpect(status().isForbidden());
    }
}
