package com.lacomer.lle.config;

import com.lacomer.lle.exception.JsonAccessDeniedHandler;
import com.lacomer.lle.exception.JsonAuthenticationEntryPoint;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.FactorGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Verifica que el claim scope se mapee a authorities literales, sin prefijo.
 *
 * @author Orlando Ferreira Angon
 */
class SecurityConfigTest {

    private final SecurityConfig config =
            new SecurityConfig(new JsonAuthenticationEntryPoint(), new JsonAccessDeniedHandler());

    private Jwt jwtConScope(Object scope) {
        return Jwt.withTokenValue("token")
                .header("alg", "RS256")
                .header("kid", "abc123XyZ")
                .claim("sub", "svc-lle")
                .claim("scope", scope)
                .build();
    }

    @Test
    void scopeComoStringSeMapeaSinPrefijo() {
        var authorities = config.jwtAuthenticationConverter()
                .convert(jwtConScope("read.lle write.lle"))
                .getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();

        assertThat(authorities).contains("read.lle", "write.lle");
        assertThat(authorities).noneMatch(a -> a.startsWith("SCOPE_"));
    }

    @Test
    void scopeComoArraySeMapeaSinPrefijo() {
        var authorities = config.jwtAuthenticationConverter()
                .convert(jwtConScope(List.of("read.lle", "admin.lle")))
                .getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();

        assertThat(authorities).contains("read.lle", "admin.lle");
    }

    /**
     * Spring Security 7 agrega FACTOR_BEARER de forma automatica en
     * JwtAuthenticationConverter. Por eso no se puede usar containsExactly.
     */
    @Test
    void seAgregaElFactorBearerAutomaticamente() {
        var authorities = config.jwtAuthenticationConverter()
                .convert(jwtConScope("read.lle"))
                .getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();

        assertThat(authorities).containsExactlyInAnyOrder(
                "read.lle",
                FactorGrantedAuthority.BEARER_AUTHORITY);
    }
}
