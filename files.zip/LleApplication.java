package com.lacomer.lle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada del Resource Server LLE.
 *
 * @author Orlando Ferreira Angon
 */
@SpringBootApplication
public class LleApplication {

    public static void main(String[] args) {
        SpringApplication.run(LleApplication.class, args);
    }
}
