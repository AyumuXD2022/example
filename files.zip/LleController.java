package com.lacomer.lle.controller;

import com.lacomer.lle.dto.LleDto;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Endpoints protegidos por scope. Los scopes llegan sin prefijo gracias al
 * JwtAuthenticationConverter configurado en SecurityConfig.
 *
 * @author Orlando Ferreira Angon
 */
@RestController
@RequestMapping("/api/lle")
public class LleController {

    private final AtomicLong secuencia = new AtomicLong(1);

    @GetMapping
    @PreAuthorize("hasAuthority('read.lle')")
    public List<LleDto> listar() {
        return List.of(new LleDto(1L, "LLE-001", "Registro de ejemplo", 10));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('read.lle')")
    public LleDto obtener(@PathVariable Long id) {
        return new LleDto(id, "LLE-%03d".formatted(id), "Registro de ejemplo", 10);
    }

    @PostMapping
    @PreAuthorize("hasAuthority('write.lle')")
    public ResponseEntity<LleDto> crear(@Valid @RequestBody LleDto dto,
                                        @AuthenticationPrincipal Jwt jwt) {
        LleDto creado = new LleDto(secuencia.incrementAndGet(), dto.clave(), dto.descripcion(), dto.cantidad());
        return ResponseEntity.ok(creado);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('write.lle')")
    public LleDto actualizar(@PathVariable Long id, @Valid @RequestBody LleDto dto) {
        return new LleDto(id, dto.clave(), dto.descripcion(), dto.cantidad());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('admin.lle') and hasAuthority('write.lle')")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        return ResponseEntity.noContent().build();
    }
}
