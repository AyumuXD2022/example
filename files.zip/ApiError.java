package com.lacomer.lle.exception;

import java.time.OffsetDateTime;

/**
 * Estructura de error de la API. Se serializa a mano para evitar acoplar los
 * handlers de seguridad a la version de Jackson del classpath.
 *
 * @author Orlando Ferreira Angon
 */
public final class ApiError {

    private ApiError() {
    }

    public static String toJson(int status, String error, String message, String path) {
        return """
                {"timestamp":"%s","status":%d,"error":"%s","message":"%s","path":"%s"}"""
                .formatted(OffsetDateTime.now(), status, escape(error), escape(message), escape(path));
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
