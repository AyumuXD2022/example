package com.lacomer.lle.controller;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Utilidad de diagnostico para verificar como quedaron mapeadas las authorities.
 * Se activa solo con lle.debug.enabled=true; no habilitar en produccion.
 *
 * @author Orlando Ferreira Angon
 */
@RestController
@RequestMapping("/api/debug")
@ConditionalOnProperty(name = "lle.debug.enabled", havingValue = "true")
public class DebugController {

    @GetMapping("/authorities")
    public Map<String, Object> authorities(Authentication authentication,
                                           @AuthenticationPrincipal Jwt jwt) {
        List<String> authorities = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .sorted()
                .toList();

        return Map.of(
                "principal", authentication.getName(),
                "authorities", authorities,
                "scopeClaim", String.valueOf(jwt.getClaim("scope")),
                "issuer", String.valueOf(jwt.getIssuer()),
                "kid", String.valueOf(jwt.getHeaders().get("kid")));
    }
}
