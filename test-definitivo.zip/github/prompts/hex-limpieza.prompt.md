---
mode: ask
description: "PASO 2 — Limpieza y simplificación sin cambiar funcionalidad (documenta los cambios)"
---

# PASO 2 — Limpieza de código

ANTES DE EMPEZAR: LEE el `build.gradle` (y el BOM) para saber qué dependencias tiene el proyecto y
qué VERSIÓN DE JAVA usa (`java { toolchain { languageVersion } }` o `sourceCompatibility`). NO uses
APIs/clases de una librería que el proyecto NO tiene; básate SOLO en lo presente. Y APÉGATE a esa
versión de Java: no introduzcas sintaxis/APIs de una versión más nueva (JDK 8: nada de `var`,
`records`, switch expression, `List.of`, text blocks; JDK 11: nada posterior). Debe seguir compilando
con esa versión; si no la sabes, pregúntala.

## Orden de trabajo (hazlo en este orden), SIEMPRE con la MISMA funcionalidad y con ANTES/DESPUÉS
1) LEE el `build.gradle`: dependencias + versión de Java (ya indicado arriba). No uses código de una
   dependencia que NO exista.
2) EMPIEZA por los DTO / Entity (y paquetes parecidos: model, dto, entity, vo, pojo):
   - Si la CLASE COMPLETA no se usa en NINGÚN lado -> elimínala (ej. `ClassName` que nadie referencia).
   - Si la clase SÍ se usa -> DÉJALA TAL CUAL: NO le quites atributos/campos aunque parezcan sin usar
     (ej. `ClassName2` usada con campos no referenciados -> no toques sus atributos). Motivo: un campo
     de DTO/Entity suele mapear BD/JSON (JPA/Jackson) o usarse por reflexión. Solo se elimina la CLASE
     entera si está sin uso.
3) DESPUÉS los MÉTODOS MUERTOS (que nadie llama) y elimínalos; igual variables/parámetros/imports sin
   usar, `import *` -> explícitos, y código comentado. No toques el código generado (SOAP).
4) AL FINAL, SIMPLIFICA el código que sí se usa (más simple y legible): booleanos redundantes, `else`
   tras `return`, `if` anidados que se unen con `&&`, operador diamante, casts redundantes,
   `try-with-resources`, duplicados a método privado. Antes de simplificar un método, ENTIENDE qué hace;
   si NO se puede simplificar sin arriesgar el comportamiento, déjalo igual (no pasa nada). La
   funcionalidad NO cambia.

## Imports explícitos (no nombres cualificados en el cuerpo)
- Si un tipo está escrito con su paquete completo, p. ej. `private com.mx.entity.Clase clase;`,
  cámbialo por un IMPORT explícito arriba + nombre SIMPLE: `import com.mx.entity.Clase;` y `private Clase clase;`.
- CHOQUE DE NOMBRES: si en el MISMO archivo se usan DOS clases distintas con el mismo nombre simple,
  no se pueden importar las dos. Entonces RENOMBRA una de las clases a un nombre claro y distinto, pon
  los imports explícitos de ambas, actualiza TODOS los usos y DOCUMENTA el antes -> después (archivo de
  la clase y dónde se usaba). Luego VERIFICA que compile. NO renombres el código GENERADO (SOAP) ni API
  pública consumida fuera del proyecto; en ese caso renombra la OTRA, y si ninguna se puede sin riesgo,
  déjalo con el paquete completo y dilo.
- Es cosmético/legibilidad: NO cambia la funcionalidad.

## Código muerto EN CASCADA
- Una referencia que viene de código MUERTO no cuenta como "uso". Si `A` usa a `B` pero `A` NO se usa
  en ningún lado, entonces `B` queda sin uso real: elimina las DOS.
- Hazlo en CASCADA: tras borrar una clase/método muerto, revisa lo que usaba; si quedó sin uso real,
  bórralo también. Repite hasta que no quede nada que solo dependiera de lo ya eliminado.
- NO aplica a DTO/Entity que SÍ se usan (no se tocan sus atributos).

## Seguro
- Para afirmar que algo no se usa, búscalo (`usages`/`search`); si no puedes verlo, NO lo borres.
- Cuidado con Spring/reflexión/JPA/serialización/endpoints. Ante CUALQUIER duda, "A revisar".
- No renombres API pública ni cambies firmas. Nada que cambie resultado o comportamiento observable.

## Documentar (obligatorio en este paso)
- Entrega una lista de TODOS los cambios hechos: archivo, qué se eliminó o simplificó y por qué,
  con ANTES/DESPUÉS. Esto queda como registro del paso.
- Verifica que COMPILE (gradle/JDK locales) y que las pruebas sigan pasando.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hex-hexagonal`.
