---
mode: ask
description: "PASO 1 — Leer TODO el proyecto y documentarlo (SOAP, generadores, REST/WebFlux, BD, arquitectura)"
---

# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y entiende cómo funciona. NO cambies nada aquí.
Trabaja con el código REAL, no inventes. Si el repo es grande, ve por paquetes y DI cuáles revisaste.

## Entorno (no descargues nada)
- Lee la versión de Gradle (`gradle-wrapper.properties`) y la de Java (`build.gradle`) y DÍSELAS a la
  persona (ej. "usa Gradle 8.14.3 y Java 21"). Pídele SOLO las RUTAS locales de esas versiones.
- Con esas rutas, indaga qué necesita el proyecto para compilar/correr en local (JDK correcto,
  `--offline`, etc.). TÚ armas los comandos; no uses `JAVA_HOME` ni `./gradlew`.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> proceso -> salida.
2. **Arquitectura ACTUAL**: cómo está organizado hoy (capas, paquetes). Identifica el estilo
   (MVC por capas, service/repository, "todo junto", etc.) y dibuja el mapa de paquetes.
3. **¿Base de datos?** motor y cómo accede (JPA/Hibernate, JdbcTemplate, Connection), entidades y
   queries principales.
4. **¿SOAP?** endpoint/WSDL y CON QUÉ HERRAMIENTA se generaron las clases (wsimport, CXF wsdl2java,
   Axis, xjc) y en qué PAQUETE quedan.
5. **¿REST o WebFlux?** si expone/consume REST (Spring MVC) o usa WebFlux/Reactor; con qué clientes
   (RestTemplate, WebClient, Feign).
6. **Generadores de clases**: LISTA TODAS las herramientas que generen clases (wsimport, xjc,
   wsdl2java, Axis), con su task del `build.gradle` y su paquete de salida. Ponlas TODAS.
7. **Config relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.

## Entrega
- Resumen en español + tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`.
- Un mapa de la ARQUITECTURA ACTUAL (lista de paquetes/capas y qué hay en cada uno). Guarda esto:
  será la base del paso `/hex-hexagonal` y del `/hex-documentar`.
- Marca "A revisar" lo que no pudiste confirmar.

RECUERDA (base): jamás `git push`/commit/PR; no agregues código de dependencias que no estén en el
`build.gradle`; no cambies funcionalidad de negocio.

Cuando termines, ejecuta `/hex-limpieza`.
