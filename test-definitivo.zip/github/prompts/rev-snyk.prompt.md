---
mode: ask
description: "PASO 5 — Snyk: si es fixable, actualizar; si no, justificar en el archivo .snyk"
---

# PASO 5 — Snyk (dependencias vulnerables)

PRIMERO PREGUNTA: "¿Tienes un informe de vulnerabilidades de dependencias de Snyk?"

- Si la persona dice **NO**: no hagas nada aquí, pasa directo a `/rev-test`.
- Si dice **SÍ**: pídele el informe y LÉELO completo. Para CADA vulnerabilidad fíjate en si tiene
  arreglo: Snyk lo indica como "fixed in <versión>" / "upgradable" / "patchable" (hay versión que
  la corrige) o como "No fix available / no hay upgrade" (sin arreglo).

## Caso A — La vulnerabilidad ES fixable (dice "fixed in <versión>")
1) LEE TODO el `build.gradle` (y el BOM) para ubicar la dependencia y su versión actual, y ver si la
   versión la fija un BOM (en ese caso puede no llevar número).
2) Confirma que la versión de arreglo EXISTE para ese `groupId:artifactId` (Maven Central /
   mvnrepository.com). Si NO tienes acceso a internet para verificarlo, NO inventes: usa la versión
   EXACTA que dice el informe de Snyk ("fixed in ...") y pide a la persona que la confirme.
3) ACTUALIZA la versión en el `build.gradle` (ANTES/DESPUÉS), respetando cómo maneja versiones el
   proyecto (número directo vs BOM/propiedad de versión).
4) Recompila con el gradle y JDK locales (PASO 2):
   `"<ruta_gradle>\bin\gradle.bat" clean build --offline -Dorg.gradle.java.home="<ruta_jdk>"`
5) Si la nueva versión CAMBIÓ algo (API renombrada/eliminada, paquetes movidos): estúdialo y AJUSTA
   el código afectado para que TODO funcione IGUAL que antes. Explica cada ajuste con ANTES/DESPUÉS.

## Caso B — La vulnerabilidad NO tiene arreglo (no fix / no upgrade disponible)
- NO inventes una versión ni "subas por subir". Si no hay versión que la arregle, NO toques el
  `build.gradle`.
- Dile a la persona que esa vulnerabilidad hay que GESTIONARLA (ignorar con justificación) en el
  archivo de política de Snyk: **`.snyk`** (en la raíz del proyecto).
- AYÚDALE a escribir la entrada en `.snyk` con su justificación. Formato:

    version: v1.5.0
    ignore:
      SNYK-JAVA-GRUPO-ID-0000000:        # <-- el ID exacto de la vuln en el informe de Snyk
        - '*':
            reason: >-
              <justificación real: por qué se acepta — no hay fix disponible, no es explotable en
              nuestro contexto, o es dependencia transitiva sin versión segura, etc.>
            expires: 2026-12-31T00:00:00.000Z   # <-- fecha de caducidad de la excusa (revísala luego)

- DÉJALE claro: hay que poner el **ID de la vulnerabilidad tal cual** del informe, una **razón real**
  (no genérica) y una **fecha de expiración** para volver a revisarla. La decisión de ignorar es de
  la persona/equipo; tú solo preparas la entrada.

## Entrega
- Tabla: `| Dependencia | ID Snyk | ¿Fixable? | Versión antes | Versión después | ¿Rompe? | Ajustes / Acción |`
  (en "Acción" pon: actualizada, o "ignorada en .snyk con justificación").
- ANTES/DESPUÉS del `build.gradle` (Caso A) o la entrada del `.snyk` (Caso B).
- Jamás `git push`/commit/PR.

Cuando termines (o si no había informe), ejecuta `/rev-test`.
