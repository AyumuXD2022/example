---
mode: ask
description: "PASO 3 — Migrar a arquitectura hexagonal SIN cambiar la funcionalidad de negocio + diagrama"
---

# PASO 3 — Migrar a Arquitectura Hexagonal (Ports & Adapters)

Toma la ARQUITECTURA ACTUAL documentada en `/hex-contexto` y reorganiza el proyecto a HEXAGONAL,
conservando EXACTAMENTE la misma funcionalidad de negocio (mismo comportamiento observable). Esto es
REESTRUCTURAR (mover código y crear puertos/adaptadores), NO reescribir la lógica.

## Capas y qué va en cada una
- **domain** (núcleo): entidades/modelos de negocio, value objects, reglas y servicios de dominio.
  NO depende de Spring, ni de JPA, ni de SOAP/REST. Aquí viven también los **puertos** (interfaces):
    - puertos de ENTRADA (casos de uso): qué puede pedirse al negocio.
    - puertos de SALIDA (repositorios/clientes): qué necesita el negocio del exterior.
- **application** (casos de uso): orquesta el dominio implementando los puertos de entrada. Sin
  detalles de framework; depende solo de `domain`.
- **infrastructure / adapters** (lo de afuera):
    - adaptadores de ENTRADA: controllers REST (Spring MVC) o handlers WebFlux, listeners, endpoints SOAP.
    - adaptadores de SALIDA: implementaciones JPA/JdbcTemplate de los repositorios, clientes REST/SOAP
      (RestTemplate/WebClient/puertos JAX-WS), colas.
    - configuración de Spring (`@Configuration`, beans), mapeos DTO<->dominio.
- El código GENERADO por el SOAP (wsimport/xjc) se queda como está y se usa SOLO desde el adaptador
  de salida SOAP; no lo metas al dominio.

## Reglas de dependencia (clave del hexagonal)
- Las dependencias apuntan HACIA ADENTRO: infrastructure -> application -> domain. El dominio NO
  conoce a nadie de afuera.
- La comunicación con el exterior pasa SIEMPRE por un PUERTO (interfaz) y su ADAPTADOR.
- Mantén la misma funcionalidad: cada caso de uso debe producir el mismo resultado que hoy.

## Cómo hacerlo (seguro, por pasos)
1) Propón la nueva estructura de paquetes (domain/application/infrastructure) y MUÉSTRALA antes de mover.
2) Extrae interfaces (puertos) para lo que hoy son services/repositories; haz que las clases actuales
   pasen a ser adaptadores que las implementan.
3) Mueve el código a su capa, ajustando imports/paquetes. Usa SOLO dependencias ya presentes en el
   `build.gradle` (no agregues librerías nuevas sin avisar).
4) Conserva las firmas públicas y el comportamiento; si algo obliga a decidir, márcalo "A revisar".
5) Verifica que COMPILE y que las pruebas existentes sigan pasando (gradle/JDK locales).

## Diagrama al finalizar (obligatorio)
Entrega un diagrama de cómo quedó, en **Mermaid**, mostrando capas, puertos y adaptadores, y las
CLASES reales que ubicaste en cada una (las que leíste) con su funcionalidad. Ejemplo de forma:

```mermaid
flowchart TB
  subgraph Infra_In[Adaptadores de entrada]
    REST[XxxController (REST)]
    SOAPIN[XxxEndpoint (SOAP)]
  end
  subgraph App[Application - Casos de uso]
    UC[XxxUseCase impl]
  end
  subgraph Domain[Domain - Núcleo]
    MODEL[Xxx (modelo)]
    PIN[[Puerto entrada: XxxService]]
    POUT[[Puerto salida: XxxRepository]]
  end
  subgraph Infra_Out[Adaptadores de salida]
    JPA[XxxRepositoryJpa]
    SOAPCLI[XxxSoapClient]
  end
  REST --> PIN
  SOAPIN --> PIN
  PIN --> UC --> MODEL
  UC --> POUT
  POUT --> JPA
  POUT --> SOAPCLI
```

Acompaña el diagrama con una tabla `| Clase | Capa | Rol (puerto/adaptador/modelo/caso de uso) | Qué hace |`.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hex-documentar`.
