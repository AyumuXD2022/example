---
mode: ask
description: "PASO 4 — Documentar el cambio: arquitectura ANTES vs arquitectura HEXAGONAL"
---

# PASO 4 — Documentar el cambio de arquitectura

Genera la documentación que compara la arquitectura ANTES (la de `/hex-contexto`) con la nueva
arquitectura HEXAGONAL (la de `/hex-hexagonal`). No cambies código aquí; solo documentas.

## Qué entregar
1. **Resumen del cambio**: en 1-2 párrafos, qué se reorganizó y por qué (el negocio quedó igual).
2. **Antes vs Después (estructura)**: tabla o dos árboles de paquetes:
   - Árbol de paquetes ANTES.
   - Árbol de paquetes DESPUÉS (domain / application / infrastructure).
3. **Mapa de movimientos por clase**: tabla
   `| Clase | Ubicación ANTES | Ubicación DESPUÉS | Capa | Rol (puerto/adaptador/modelo/caso de uso) |`.
4. **Puertos y adaptadores creados**: lista de interfaces (puertos de entrada/salida) nuevas y qué
   clase las implementa (adaptador).
5. **Qué NO cambió**: deja claro que la funcionalidad de negocio es la misma (mismos resultados,
   mismos endpoints/contratos). Si algo quedó "A revisar", lístalo.
6. **Diagramas**: incluye el diagrama Mermaid del hexagonal (del paso 3) y, si ayuda, un diagrama
   simple del "antes" para comparar.

Formato: Markdown claro (sirve para un README o una wiki). No inventes; básate en lo que realmente
moviste y leíste.

JAMÁS hagas `git add`/`commit`/`push` ni PR en este paso. El commit lo hace la persona.

Cuando termines, ejecuta `/hex-test`.
