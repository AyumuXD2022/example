---
mode: ask
description: "PASO 1 — Leer TODO el proyecto y documentarlo (SOAP, BD, servicios, generadores)"
---

# PASO 1 — Contexto: leer todo el código y documentarlo

Lee el proyecto COMPLETO con @workspace / #codebase y empápate de cómo funciona. NO cambies nada
en este paso: solo entender y documentar. Trabaja con el código REAL, no inventes.

NOTA: `@workspace` no siempre mete el repo entero al contexto. Si el proyecto es grande, ve por
paquetes/carpetas y DILO ("revisé estos paquetes"). No afirmes algo de código que no viste.

## Primero: ¿cómo se construye el proyecto?
- Busca el `build.gradle` (y `settings.gradle` / `gradle/wrapper/`).
- Si NO encuentras `build.gradle` en ninguna parte, NO asumas Gradle. PREGUNTA a la persona:
  "No veo un `build.gradle`. ¿Es un Java Project de Eclipse (sin Gradle)?"
  Y mientras tanto detecta qué tipo de proyecto es, por sus archivos:
    * Eclipse Java Project clásico -> tiene `.project` y `.classpath` (y carpeta `bin/`), compila con Eclipse.
    * Maven  -> tiene `pom.xml`.
    * Ant    -> tiene `build.xml`.
- DILE qué detectaste y espera confirmación. Si es Eclipse/Maven/Ant (no Gradle), AVISA que los pasos
  que usan Gradle (entorno, compilar, `jacocoTestReport`) se harán con la herramienta real de ESE
  proyecto, y pide cómo compila/prueba la persona antes de seguir. No inventes comandos de Gradle.

### Si es un Java Project (Eclipse, sin gestor de dependencias)
- No hay `build.gradle`/`pom.xml` que liste las dependencias. Para revisar el código y lo COMPILADO,
  PIDE a la persona la RUTA de la carpeta donde están CONCENTRADAS todas las librerías (los `.jar`),
  normalmente `lib/` o la que use el `.classpath`. Esa carpeta de jars hace de "dependencias": úsala
  para saber qué librerías/APIs existen (NO asumas ninguna que no esté ahí).
- PREGUNTA qué **versión de Java (JDK)** usa el proyecto y pídele la RUTA de ese JDK. A partir de ahí,
  TODOS los pasos (sobre todo `/rev-limpieza`) deben APEGARSE a ESA versión de Java: no introduzcas
  sintaxis ni APIs de una versión más nueva (ej. si es JDK 8, nada de `var`, `records`, `switch`
  expression, `List.of`, text blocks, etc.; si es JDK 11, nada de lo que llegó después). El código debe
  seguir compilando con la versión que te diga, no con otra.

## Qué documentar
1. **Propósito y flujo general**: qué hace el servicio, entrada -> procesamiento -> salida.
2. **Componentes**: controllers, services, repositorios, clientes, config, utilidades.
3. **¿Accede a BASE DE DATOS?** Sí/No. Si sí: motor (Oracle, SQL Server, etc.), cómo se conecta
   (JPA/Hibernate, JdbcTemplate, Connection directa), entidades/queries principales.
4. **¿Es o consume SOAP?** Sí/No. Si sí:
   - Endpoint(s) / WSDL que usa.
   - **Con qué herramienta se generaron las clases del SOAP** (wsimport de JAX-WS, CXF `wsdl2java`,
     Apache Axis, JAXB `xjc`, el plugin de Gradle que sea). Mira el `build.gradle` (tasks/plugins
     como `wsimport`, `wsdl2java`, `jaxws`, `jaxb`, `xjc`) y los paquetes generados.
   - En qué PAQUETE quedan las clases generadas (ej. `com.bns.xsd.*`).
5. **¿Consume OTRO servicio (REST/HTTP u otro)?** Sí/No. Si sí: cuál, con qué cliente
   (RestTemplate, WebClient, Feign, OkHttp) y a qué URL/base.
6. **Generadores de clases a partir de XML/WSDL/XSD**: LISTA TODAS las herramientas que encuentres
   que generen clases (wsimport, xjc, wsdl2java, Axis, plugins de Gradle), con el task del
   `build.gradle` y el paquete de salida de cada una. Ponlas TODAS, no solo una.
7. **Configuración relevante**: `application.yml/properties` (sin exponer secretos), perfiles, URLs.

## Entrega
- Un resumen claro en español con los puntos de arriba.
- Una tabla: `| Área | ¿Aplica? | Herramienta/Tecnología | Paquete/Ubicación |`
- Marca con "A revisar" lo que no pudiste confirmar.

## ¿Es Spring o Java normal? (decide qué pasos siguen)
Determina si el proyecto usa **Spring / Spring Boot**: búscalo en el `build.gradle`/`pom.xml`
(dependencias `org.springframework...`, `spring-boot-starter-*`) y en el código
(`@SpringBootApplication`, `@RestController`, `@Service`, `@Autowired`). DILO claramente.
- Si ES Spring: continúa con el flujo COMPLETO (entorno -> `/rev-limpieza` -> `/rev-checkmarx` -> `/rev-snyk` -> `/rev-test`).
- Si es un Java Project NORMAL (SIN Spring): el flujo es CORTO. Solo harás `/rev-limpieza` y luego
  `/rev-checkmarx`. En `/rev-checkmarx`: si hay informe, lo mitigas; si NO hay informe, TERMINAS ahí.
  NO hagas `/rev-snyk` ni `/rev-test`. Avísale esto a la persona.

RECUERDA (reglas base): jamás `git push`/commit/PR, y en los siguientes pasos no agregues código de
dependencias que no estén en el `build.gradle`.

Cuando termines, si ES Spring ejecuta el **PASO 2 (entorno)**: dime qué versión de Gradle y de Java
usa el proyecto y pídeme SOLO las rutas locales; luego sigue con `/rev-limpieza`. Si es Java normal,
pasa directo a `/rev-limpieza` (y después `/rev-checkmarx`).
