---
mode: ask
description: "PASO 5 — Pruebas y cobertura; excluir el SOAP generado en Sonar/JaCoCo"
---

# PASO 5 — Pruebas, cobertura y exclusiones

## 1) Dependencias de prueba (lee el build.gradle primero)
- PRIMERO LEE el `build.gradle` para ver qué dependencias ya existen (no dupliques) y en qué scope.
- Si faltan dependencias para poder probar, AGRÉGALAS pero SOLO de ámbito de PRUEBA
  (`testImplementation` / `testRuntimeOnly` / `testCompileOnly` / `testAnnotationProcessor`). NUNCA
  toques producción. Usa SOLO APIs de dependencias que estén en el `build.gradle`; no pongas código de
  una librería que no existe. Reporta qué agregaste y por qué.
- Nombres correctos (OJO con los que NO existen):
    * NO existe 'org.springframework.boot:spring-boot-starter-webmvc'  -> MVC va en 'spring-boot-starter-web'
    * NO existe 'org.springframework.boot:spring-boot-starter-security-test'
         -> es 'org.springframework.security:spring-security-test'
    * @WebMvcTest/MockMvc ya vienen en 'org.springframework.boot:spring-boot-starter-test'
- Base: `testImplementation 'org.springframework.boot:spring-boot-starter-test'` +
  `testRuntimeOnly 'org.junit.platform:junit-platform-launcher'`.

## 2) Exclusiones en sonar-project.properties (NO lo crees — YA existe)
- El proyecto YA tiene su `sonar-project.properties`. NUNCA lo crees ni lo reestructures.
- Solo ÁBRELO y mira `sonar.exclusions` y `sonar.coverage.exclusions`. AGREGA ahí la(s) clase(s)
  GENERADA(S) por el SOAP (wsimport/xjc/wsdl2java detectado en `/hex-contexto`) para EXCLUIRLAS, con el
  MISMO formato de rutas que ya use el archivo, sin borrar lo demás. No excluyas tu código de negocio.
- CONFIGURACIÓN: PRIMERO intenta PROBAR lo que tenga lógica (una `@Configuration` que arma un bean con
  lógica, un converter, etc.) — probar es mejor que excluir. SOLO lo que de verdad NO se puede testear
  (puro cableado, constantes, enums, `@SpringBootApplication` main) se excluye de `sonar.coverage.exclusions`
  (no de `sonar.exclusions`) para que no salga en 0%. La decisión FINAL se toma en el paso 5 mirando el
  reporte. NO excluyas dominio/aplicación/adaptadores con lógica: eso se prueba.

## 3) Generar las pruebas (meta: >= 85%, ideal 100%)
- JUnit 5 + Mockito. Slice correcto según la capa hexagonal:
    - dominio/casos de uso -> pruebas unitarias puras (sin Spring), mockeando los PUERTOS de salida.
    - adaptadores de entrada REST -> `@WebMvcTest`; WebFlux -> `WebTestClient`.
    - adaptadores de salida -> mockea Connection/cliente; repos JPA -> `@DataJpaTest`/H2 si aplica.
- Patrón AAA, aserciones reales. Cubre caminos felices y de error, y ramas (if/else, switch, catch, null).
- No gastes pruebas en lo EXCLUIDO (SOAP generado).

## 4) Correr pruebas + JaCoCo y LEER los resultados
- Corre con el gradle y JDK locales:
    "<ruta_gradle>\bin\gradle.bat" clean test jacocoTestReport --offline -Dorg.gradle.java.home="<ruta_jdk>"
- Cuando TODAS pasen, LEE el reporte `build/reports/jacoco/test/html/index.html` (o el
  `jacocoTestReport.xml`). Si no está, pide la RUTA y léelo en ese momento.

## 5) Mirar las clases en 0%, clasificarlas y excluir solo lo que corresponde (y re-verificar)
- En el reporte, LOCALIZA las clases en 0% (o muy bajas). Para CADA una decide:
  * código GENERADO por el SOAP -> exclúyela.
  * pura CONFIGURACIÓN / sin lógica (config, `@SpringBootApplication` main, constantes, enums) -> exclúyela.
  * con lógica (dominio/aplicación/adaptadores) -> NO la excluyas: AGRÉGALE pruebas.
- Lo que toque excluir, agrégalo al `exclude` del bloque `jacocoTestReport` del `build.gradle` (mismo
  formato de ruta, paquete real del `build.gradle`/`contexto`, no ejemplos) y a `sonar.coverage.exclusions`.
- VUELVE a correr `test jacocoTestReport` y VERIFICA en el reporte (`build/reports/jacoco/test/html/index.html`)
  que las clases que excluiste (SOAP y configuración) ya NO aparecen y que la cobertura refleja el
  cambio. Si alguna sigue, revisa la ruta del `exclude` y repite hasta que quede excluida.
- NO excluyas tu propio código con lógica (dominio/aplicación/adaptadores) para inflar cobertura: si
  una clase propia queda baja, AGREGA pruebas.

## Entrega
- Qué se excluyó (sonar-project.properties y jacocoTestReport) y por qué.
- Dependencias de test agregadas (solo test) y por qué.
- Pruebas generadas (código completo) y cobertura final; qué falta para el 85% si no se llegó.
- Jamás `git push`/commit/PR.
